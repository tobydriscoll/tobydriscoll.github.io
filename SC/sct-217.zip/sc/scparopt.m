function [trace,tol,method] = scparopt(options)
%SCPAROPT Parameters used by S-C parameter problem routines.
%   OPTIONS(1): Nonzero causes some intermediate results to be
%               displayed (default 0)
%   OPTIONS(2): Error tolerance for solution (default 1e-8)
%   OPTIONS(3): Solution strategy
%                  1 = line search
%                  2 = trust region (default)
%   
%   See also HPPARAM, DPARAM, DEPARAM, STPARAM, RPARAM.

%   Copyright 1998 by Toby Driscoll.
%   $Id: scparopt.m,v 2.1 1998/05/10 04:53:44 tad Exp $

user = options;
lenu = length(user);
options = zeros(1,3);
options(1:lenu) = user(1:lenu);
options = options + (options==0).*[0,1e-8,2];

trace = options(1);
tol = options(2);
method = options(3);

