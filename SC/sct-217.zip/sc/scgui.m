function out = scgui(varargin)
%SCGUI  Create graphical user interface for SCM Toolbox.
%   SCGUI creates the graphical user interface (GUI) menus for the
%   Schwarz-Christoffel Toolbox in a new figure window.
%
%   Use of the GUI is straightforward.  For complete details, see the
%   user's guide.
%
%   See also SCGGET, SCGSET.

%   Copyright 1998 by Toby Driscoll.
%   $Id: scgui.m,v 2.8 1999/09/14 20:40:14 tad Exp $

% If called from the GUI, reroute to function cback
if nargin > 1
  out = cback(varargin{:});
  return
end
  
fig = figure('name','Schwarz-Christoffel Mapping','numbertitle','off');
set(fig,'defaultuicontrolinterrupt','on','unit','point')
figpos = get(fig,'pos');
unit = get(0,'unit');
set(0,'unit','point')
maxpos = get(0,'screensize');
set(0,'unit',unit)

% Set desired figure size
figsize = [462 396];
delta = figsize - figpos(3:4);
figpos(1) = max(min(figpos(1),maxpos(3)-figsize(1)),0); % move left if needed
figpos(2) = max(figpos(2)-delta(2),0); % move bottom down, not top up
figpos(3:4) = figsize;
set(fig,'pos',figpos)
set(fig,'resizefcn','scgui(gcbo,''resize'');')

% Create axes
ax(1) = axes('units','point','tag','phydomain');
ax(2) = axes('units','point','tag','candomain');
set(ax,'next','add','box','on','plotboxaspectratio',[1 1 1])

% Create widgets and set sizes appropriately (subfunctions)
make_widgets(fig);
resize_widgets(fig)

data.polygon = [];
data.map = [];
data.iscurrent = 0;
data.phypoints = [];
data.canpoints = [];
setuprop(fig,'mapdata',data)


function out = cback(fig,cmd,aux)

out = [];
mapclass = { 'diskmap','hplmap','stripmap','rectmap','extermap', ...
    'crdiskmap','crrectmap' };

switch cmd

case 'draw'				%*** Draw button
  % Make physical domain visible
  ax(1) = findobj(fig,'tag','phydomain');
  ax(2) = findobj(fig,'tag','candomain');
  viewdomain = get(findobj(fig,'tag','viewdomain'),'value');
  set(findobj(fig,'tag','viewdomain'),'value',1)
  scgui(fig,'view');

  data = getuprop(fig,'mapdata');
  
  set(ax(1),'buttondown','')		% turn off point mapping
  delete(findobj(ax(1),'tag','polygon'))
  pphan = findobj(fig,'tag','phypoints');
  set(pphan,'vis','off')
  meshlines = findobj(fig,'tag','meshlines');
  set(meshlines,'vis','off')
  axis auto
  frame(1) = findobj(fig,'tag','ui_settings');
  frame(2) = findobj(fig,'tag','ui_actions');
  uihandles = getuprop(fig,'uihandles');
  set(uihandles,'vis','off')

  % If drawpoly dies, clear the figure's callbacks 
  try
    p = drawpoly(fig);
  catch
    set(fig,'windowbuttondownfcn','')
    set(fig,'windowbuttonmotionfcn','')
    set(fig,'windowbuttonupfcn','')
    set(fig,'keypressfcn','')
    p=polygon([]);
  end

  set(uihandles,'vis','on')
  drawnow
  
  if ~isempty(p)
    % New polygon
    data.polygon = p;
    data.map = [];
    data.iscurrent = 0;
    axes(ax(2))
    cla 
    axes(ax(1))
    cla
    data.phypoints = [];
    data.canpoints = [];
    scgui(fig,'domain');
  else
    % Action was canceled
    set(pphan,'vis','on')
    set(meshlines,'vis','on')
  end
  
  if ~isempty(data.polygon)
    h = plot(data.polygon);
    set(h,'tag','polygon')
  end

  setuprop(fig,'mapdata',data)
  set(findobj(fig,'tag','viewdomain'),'value',viewdomain)
  scgui(fig,'view');

case 'modify'				%*** Modify button
  data = getuprop(fig,'mapdata');
  p = data.polygon;
  if ~isempty(p) 			% polygon must exist!
    n = length(p);
    ax(1) = findobj(fig,'tag','phydomain');
    ax(2) = findobj(fig,'tag','candomain');
    viewdomain = get(findobj(fig,'tag','viewdomain'),'value');
    set(findobj(fig,'tag','viewdomain'),'value',1)
    scgui(fig,'view');
    
    set(ax(1),'buttondown','')		% turn off point mapping
    delete(findobj(ax(1),'tag','polygon'))
    pphan = findobj(fig,'tag','phypoints');
    set(pphan,'vis','off')
    meshlines = findobj(fig,'tag','meshlines');
    set(meshlines,'vis','off')
    uihandles = getuprop(fig,'uihandles');
    set(uihandles,'vis','off')

    axes(ax(1))
    [p1,idx] = modify(p);

    set(uihandles,'vis','on')
    changed = 0;
    w = vertex(p);
    w1 = vertex(p1);
    % Was anything really changed?
    if length(p1) ~= length(p)
      changed = 1;
    elseif norm(w(~isinf(w))-w1(~isinf(w1))) > 1000*eps
      changed = 1;
    end
    if changed
      data.polygon = p1;
      data.iscurrent = 0;
      axes(ax(2))
      cla 
      axes(ax(1))
      cla 
      data.phypoints = [];
      data.canpoints = [];
      if any(isnan(idx)) | any(diff([0;idx;n+1])~=1)
	% Cannot use continuation if vertices were added/deleted.
	data.map = [];
      end
      scgui(fig,'domain');
      set(findobj(fig,'tag','viewdomain'),'value',viewdomain)
      scgui(fig,'view');
    else
      % Status quo
      set(pphan,'vis','on')
      set(meshlines,'vis','on')
    end
    axes(ax(1))
    setuprop(fig,'mapdata',data)
    h = plot(data.polygon);
    set(h,'tag','polygon')
  end

case 'edit'				%*** Edit button
  data = getuprop(fig,'mapdata');
  w = vertex(data.polygon);
  if ~isempty(w)
    if any(isinf(w))
      fprintf('Cannot edit vertices of unbounded polygons.\n')
      return
    end
    n = length(w);
    
    % Call edit window
    [flag,w] = scgedit('Edit vertices','Vertices:',w);

    if flag > 0				% action was taken
      ax(1) = findobj(fig,'tag','phydomain');
      ax(2) = findobj(fig,'tag','candomain');
      axes(ax(2))
      cla 
      axes(ax(1))
      cla 
      data.polygon = polygon(w);
      data.iscurrent = 0;
      data.phypoints = [];
      data.canpoints = [];

      if length(w)~=n
	% No way to be a continuation
	data.map = [];
      end
      
      set(findobj(fig,'tag','viewdomain'),'value',1)
      scgui(fig,'view');
      h = plot(data.polygon);
      set(h,'tag','polygon')
      scgui(fig,'domain');
      setuprop(fig,'mapdata',data)
    end
  end    
  
case 'solve'				%*** Solve button
  mapnum = get(findobj(fig,'tag','domain'),'value');
  data = getuprop(fig,'mapdata');
  p = data.polygon;
  if ~isempty(p)
    oldmap = data.map;
    trace = get(findobj(fig,'tag','trace'),'value');
    tol = str2num(get(findobj(fig,'tag','tol'),'string'));
    ax(1) = findobj(fig,'tag','phydomain');
    ax(2) = findobj(fig,'tag','candomain');
    data.iscurrent = 0;
    
%%    % Force the physical domain temporarily
%%    domainmenu = findobj(fig,'tag','viewdomain');
%%    domain = get(domainmenu,'value');
%%    set(domainmenu,'value',1)
%%    scgui(fig,'view');
    
    set(ax,'buttondown','')
    axes(ax(2))
    cla 
    axis auto
    axis normal
    drawnow
    axes(ax(1))
    
    if trace == 1
      trace = 'on';
    else
      trace = 'off';
    end
    opt = scmapopt('Trace',trace,'Tol',tol);
    
    if ~isempty(oldmap)
      % Continuation
      mapcmd = sprintf('map = %s(oldmap,p,opt);',mapclass{mapnum});
    else
      mapcmd = sprintf('map = %s(p,opt);',mapclass{mapnum});
    end
    
    fprintf('Solving parameter problem...\n')
    title('Solving...'), drawnow
    eval(mapcmd)
    
    fprintf('...finished.\n')
    title(''), drawnow

    % Store new map
    if ~isempty(map)
      data.map = map;
      data.iscurrent = 1;
      data.phypoints = [];
      data.canpoints = [];
      
      % Re-obtain polygon from the map
      p = polygon(map);
      data.polygon = p;
    end

    cla 
    axis auto
    h = plot(p);
    set(h,'tag','polygon')

    % Create physical points object
    hp = findobj(fig,'tag','phypoints');
    if isempty(hp)
      line('linestyle','none','marker','o','markersize',5,'color',[1 0 1],...
	  'markerfacecolor',[1 0 1],'tag','phypoints','xdata',[],'ydata',[])
    end

    setuprop(fig,'mapdata',data)
%%    set(domainmenu,'value',domain)
    scgui(fig,'plotcanonical');
    scgui(fig,'view');
  end

case 'plotcanonical'			%*** plot canonical domain
  data = getuprop(fig,'mapdata');
  if data.iscurrent
    % Draw the canonical domain
    axes(findobj(fig,'tag','candomain'))
    delete(findobj(gca,'tag','polygon'))
    z = parameters(data.map);
    z = z.prevertex;

    switch class(data.map)
    case { 'diskmap','extermap','crdiskmap' }
      h = plot(exp(i*linspace(0,2*pi,100)),'linewid',1);
      axis normal
      axis equal
      axis square
      axis([-1.1 1.1 -1.1 1.1])
    case 'hplmap'
      xmin = min(z(~isinf(z)));
      xmax = max(z(~isinf(z)));
      xlim = [1.1*xmin-.1*xmax,1.1*xmax-.1*xmin];
      h = plot(xlim,[0,0],'linewid',1);
      axis normal
      axis equal
      axis square
      axis([xlim,-.1,1])
    case 'stripmap'
      minx = min(real(z(~isinf(z))));
      maxx = max(real(z(~isinf(z))));
      d = (maxx-minx)/2;
      m = (maxx+minx)/2;
      h(1) = plot([m-1.2*d,m+1.2*d],[0,0],'linewid',1);
      h(2) = plot([m-1.2*d,m+1.2*d],[1,1],'linewid',1);
      axis normal
      axis equal
      axis([m-1.2*d,m+1.2*d,-.1,1.1])
    case { 'rectmap','crrectmap' }
      h = plot(polygon(z));
      axis equal
    end 	

    % Create canonical points object
    hp = findobj(fig,'tag','canpoints');
    if isempty(hp)
      line('linesty','none','marker','o','markersize',5,'color',[1 0 1],...
	  'markerfacecolor',[1 0 1],'tag','canpoints','xdata',[],'ydata',[])
      hold on
    end

    setuprop(fig,'mapdata',data)
    
    set(h,'tag','polygon')
    h = plot(z+eps*i,'.','markersize',16,'color','k');
    set(h,'tag','polygon')
  end

case 'center'				%*** Center button
  data = getuprop(fig,'mapdata');
  % Only applies to current disk maps
  isdisk = strmatch(class(data.map),{'diskmap','crdiskmap'});
  if data.iscurrent & isdisk
    ax(1) = findobj(fig,'tag','phydomain');
    ax(2) = findobj(fig,'tag','candomain');
    % Show physical domain & turn off point mapping
    set(findobj(ax(1)),'vis','on')
    set(findobj(ax(2)),'vis','off')
    set(ax(1),'buttondown','')
    set(ax(2),'buttondown','')

    % Get point and do calculation
    axes(ax(1))
    title('Click at conformal center')
    [xc,yc] = ginput(1);
    title('')
    data.map = center(data.map,xc+i*yc);
    
    delete(findobj(fig,'tag','meshlines'))
    set(findobj(fig,'tag','phypoints'),'xdata',[],'ydata',[])
    data.phypoints = [];
    set(findobj(fig,'tag','canpoints'),'xdata',[],'ydata',[])
    data.canpoints = [];
    scgui(fig,'plotcanonical');
    scgui(fig,'view');
    setuprop(fig,'mapdata',data)
    
  end

case 'display'				%*** Display button
  data = getuprop(fig,'mapdata');
  if data.iscurrent
    display(data.map)
  end

case 'plot'				%*** Plot button
  data = getuprop(fig,'mapdata');
  if data.iscurrent
    ax(1) = findobj(fig,'tag','phydomain');
    ax(2) = findobj(fig,'tag','candomain');

    % Parse mesh line widgets
    xrhan = findobj(fig,'tag','XR');
    ythan = findobj(fig,'tag','YT');
    xrstring = get(xrhan,'string');
    ytstring = get(ythan,'string');
    if strcmp(xrstring,'defaults') | strcmp(xrstring,'default')
      xr = 10;
    else
      xr = str2num(xrstring);
    end
    if strcmp(ytstring,'defaults') | strcmp(ytstring,'default')
      yt = 10;
    else
      yt = str2num(ytstring);
    end

    % Bring up physical domain and clear old mesh lines
%%    set(findobj(ax(1)),'vis','on')
%%    set(findobj(ax(2)),'vis','off')
    ml = findobj(ax,'tag','meshlines');
    set(ml,'erase','normal')
    delete(ml)
    delete(findobj(ax(1),'tag','polygon'))
    drawnow
    
    % Exterior map: Allow axis autoscale
    if strcmp(class(data.map),'extermap')
      set(ax(1),'xlimmode','auto','ylimmode','auto')
    end

    % Do the plot
    [h,xr,yt] = plot(data.map,xr,yt);
    set(h,'erasemode','none','tag','meshlines')
    
    % Major kludge. Plotting routines plot their own copy of the polygon,
    % without returning handles. This locates and tags these lines.
    colr = get(ax(1),'colororder');
    hp = findobj(ax(1),'color',colr(1,:));
    set(hp,'tag','polygon')
    
    % Update mesh line widgets
    if isempty(xr)
      xrstring = '';
    else
      xrstring = ['[',sprintf('%.3g ',xr),']'];
    end
    isdisk = strcmp(class(data.map),'diskmap');
    isdisk = isdisk | strcmp(class(data.map),'extermap');    
    if isempty(yt)
      ytstring = '';
    elseif isdisk
      ytstring = ['pi*[',sprintf('%.3g ',yt/pi),']'];
    else
      ytstring = ['[',sprintf('%.3g ',yt),']'];
    end
    set(xrhan,'string',xrstring)
    set(ythan,'string',ytstring)

    % May want to fix up the canonical domain
    axes(ax(2))
    z = prevertex(data.map);
    switch class(data.map)
      case {'diskmap','extermap','crdiskmap'}
      case 'hplmap'
	zf = z(~isinf(z));
	xlim = [min(zf);max(zf)];
	xlim = [1.1 -.1; -.1 1.1] * xlim;
	ylim = [0;max(zf)];
	ylim = [0 0; -.1 1.1]*ylim;
	axis([xlim',-0.05*ylim(2),ylim(2)])
      case 'stripmap'
%%	zf = z(~isinf(z));
%%	xlim = [min(zf);max(zf)];
%%	xlim = [1.1 -.1; -.1 1.1] * xlim;
%%	axis([xlim',-.1,1.1])
      case 'rectmap'
      case 'crrectmap'
    end
  end
  % Want to do this so that the buttondown of the mesh lines is set up.
  scgui(fig,'view');
  
case 'mappts'				%*** map selected points
  domain = get(gca,'tag');
  data = getuprop(fig,'mapdata');
  source = aux;				% (given)
  images = [];
  if data.iscurrent
    title('Mapping...')
    drawnow

    if ~isempty(source)
      % Forward/inverse map, depending on plane in view
      if strcmp(domain,'phydomain')
	images = evalinv(data.map,source);
      elseif strcmp(domain,'candomain')
	images = eval(data.map,source);
      end
    else
      images = [];
    end

    title('')
    drawnow
  end
  out = images;
  
case 'addpt'				%*** add selected point (click)
  pt = get(gca,'currentpoint');
  % Map it
  img = scgui(fig,'mappts',pt(1,1)+i*pt(1,2));
  ax(1) = findobj(fig,'tag','phydomain');
  ax(2) = findobj(fig,'tag','candomain');
  domain = find(gca==ax);
  
  data = getuprop(fig,'mapdata');

  h = [findobj(fig,'tag','phypoints') findobj(fig,'tag','canpoints')];

  % Update objects to show points
  axes(ax(domain))
  set(h,'erasemode','none')
  xs = [get(h(domain),'xdata') pt(1,1)];
  ys = [get(h(domain),'ydata') pt(1,2)];
  set(h(domain),'xdata',xs,'ydata',ys)
  xi = [get(h(3-domain),'xdata') real(img)];
  yi = [get(h(3-domain),'ydata') imag(img)];
  set(h(3-domain),'xdata',xi,'ydata',yi)
  if domain==1
    data.phypoints = xs + i*ys;
    data.canpoints = xi + i*yi;
  else
    data.phypoints = xi + i*yi;
    data.canpoints = xs + i*ys;
  end
  set(h,'erasemode','normal')

  setuprop(fig,'mapdata',data)
  
case 'editpts'				%*** Edit points button
  domain = get(gca,'tag');
  if isempty(domain), return, end
  data = getuprop(fig,'mapdata');
  pphan = findobj(fig,'tag','phypoints');
  cphan = findobj(fig,'tag','canpoints');
  
  % Solution and points objects must exist
  if data.iscurrent
    wp = get(pphan,'xdata')+i*get(pphan,'ydata');
    zp = get(cphan,'xdata')+i*get(cphan,'ydata');
    wp = wp(~isnan(wp));
    zp = zp(~isnan(zp));
    
    % Interpretation of box depends on current view domain
    if strcmp(domain,'phydomain')
      [flag,wp] = scgedit('Edit points','Physical',wp);
      if flag > 0
	zp = scgui(fig,'mappts',wp);
      end
    elseif strcmp(domain,'candomain')
      [flag,zp] = scgedit('Edit points','Canonical',zp);
      if flag > 0
	wp = scgui(fig,'mappts',zp);
      end
    end
    if flag > 0
      % Update point objects
      set(pphan,'xdata',real(wp(:))','ydata',imag(wp(:))')
      set(cphan,'xdata',real(zp(:))','ydata',imag(zp(:))')
      data.phypoints = wp(:);
      data.canpoints = zp(:);
      setuprop(fig,'mapdata',data)
    end
  end
  
case 'importexport'			%*** Import/Export button
  % Find import/export window, or create if necessary
  fig2 = findobj(0,'tag','sc_importexport');
  if isempty(fig2)
    fig2 = make_importexportfig;
  else
    figure(fig2)
  end					% (create window)
  setuprop(fig2,'scfig',fig)
  
  % Reveal window and wait for action
  set(fig2,'vis','on')
  uiwait(fig2)
  set(fig2,'vis','off')			% turn it off

case 'importupdate'                     %*** update after import
  % Data was imported. Update the information.
  data = getuprop(fig,'mapdata');
  delete(findobj(fig,'tag','meshlines'))
  
  % Draw polygon
  axes(findobj(fig,'tag','phydomain'))
  cla
  axis auto
  h = plot(data.polygon);
  set(h,'tag','polygon');

  % Set physical points
  if data.iscurrent
    phypts = data.phypoints;
    canpts = data.canpoints;
  else
    phypts = [];
    canpts = [];
  end
  h = findobj(fig,'tag','phypoints');
  if isempty(h)
    h=line('linestyle','none','marker','o','color',[1 0 1],...
           'tag','phypoints','xdata',[],'ydata',[]);
  end
  set(h,'xdata',real(phypts),'ydata',imag(phypts))
  
  % Set canonical domain type if map given
  if data.iscurrent
    h = findobj(fig,'tag','domain');
    set(h,'value',strmatch(class(data.map),mapclass))
  end
  
  scgui(fig,'plotcanonical');
  
  % Set canonical points
  h = findobj(fig,'tag','canpoints');
  set(h,'xdata',real(canpts),'ydata',imag(canpts))
  
  scgui(fig,'domain');
  scgui(fig,'view');

  
case 'view'				%*** set phys/can view
  ax(1) = findobj(fig,'tag','phydomain');
  ax(2) = findobj(fig,'tag','candomain');
  viewdom = get(findobj(fig,'tag','viewdomain'),'value');
  data = getuprop(fig,'mapdata');
  % Set axes positions
  window = getuprop(fig,'axeswindow');
  if viewdom==1 | viewdom==2
    set(ax,'pos',window)
  else
    % They must occupy the window together
    dx = .46*window(3);
    dy = window(4);
    set(ax(1),'pos',[window(1) window(2) dx dy])
    set(ax(2),'pos',[window(1)+window(3)-dx window(2) dx dy])
  end
  % Set visibility, map-on-click functions
  vis = [viewdom~=2 viewdom~=1];
  set(findobj(ax(vis)),'visible','on')
  set(findobj(ax(~vis)),'visible','off')
  % All children get the buttondown set. This is because lines can "hide"
  % the axes. In v 5.2, the 'hittest' property is the right fix, but I
  % don't want to go there yet.
  if ~isempty(data) & data.iscurrent
    set(findobj(ax(vis)),'buttondown','scgui(gcf,''addpt'');')
  else
    set(findobj(ax(vis)),'buttondown','')
  end
  set(findobj(ax(~vis)),'buttondown','')
  if sum(vis)==1
    axes(ax(vis))
  end
     
case 'domain'				%*** canonical domain selection
  mapnum = get(findobj(fig,'tag','domain'),'value');
  %type = {'disk','half-plane','strip','rectangle','exterior'};
  data = getuprop(fig,'mapdata');
  curmapnum = strmatch(class(data.map),mapclass);
  
  if ~isempty(curmapnum) & mapnum~=curmapnum
    % Map type has been changed, so kill old map
    data.map = [];
    data.iscurrent = 0;
    data.phypoints = [];
    data.canpoints = [];
    delete(findobj(fig,'tag','phypoints'))
    axes(findobj(fig,'tag','candomain'))
    cla
    setuprop(fig,'mapdata',data);
  end
  
  % Mesh line options should be r/theta or x/y
  set(findobj(fig,'tag','XR'),'string','defaults');
  set(findobj(fig,'tag','YT'),'string','defaults');
  xrtext = findobj(fig,'tag','XRtext');
  yttext = findobj(fig,'tag','YTtext');
  if mapnum==1 | mapnum==5
    set(xrtext,'string','r =')
    set(yttext,'string','theta =')
  else
    set(xrtext,'string','x =')
    set(yttext,'string','y =')
  end
  
  % Clear all current mesh lines 
  delete(findobj(fig,'tag','meshlines'))

case 'quit'
  if strcmp(questdlg('Really quit?','Quit S-C Mapping'),'Yes')
    delete([findobj(0,'tag','sc_importexport') fig])
  end

case 'resize'
  % Figure was resized. Update widget sizes.
  resize_widgets(fig);
  
end


function [flag,x1,x2] = scgedit(name,xlab1,x1,xlab2,x2)
%SCGEDIT (not intended for calling directly by the user)
%   Pops up a figure window to edit some data.

%   Copyright 1997 by Toby Driscoll. Last updated 04/11/97.

nvar = 1;
if nargin==5
  nvar = 2;
end

fig2 = figure('vis','off','number','off','menu',menubar,'name',name);
pos = get(fig2,'pos');
height = 150-34*(nvar==1);
set(fig2,'pos',[pos(1),pos(2),400,height])
uicontrol(fig2,'style','frame','pos',[0,0,400,height]);
for j=1:nvar
  height = 64+34*(nvar-j);
  eval(sprintf('xlab=xlab%d;x=x%d(:);',j,j))
  uicontrol(fig2,'style','text','pos',[10,height,80,24],...
      'string',xlab,'hor','r');
  xstr = ['[ ',sprintf(' %.4g%+.4gi ',[real(x)';imag(x)']),']'];
  ui(j) = uicontrol(fig2,'style','edit','pos',[100,height,290,24],...
      'string',xstr,'tag','scgeditbox');
end
uicontrol(fig2,'style','push','pos',[40,20,60,24],...
    'string','Clear','call',...
    'set(findobj(gcf,''tag'',''scgeditbox''),''string'',''[ ]'')')
uicontrol(fig2,'style','push','pos',[170,20,60,24],...
    'string','Done','call','global SC_FLAG,SC_FLAG=1;')
uicontrol(fig2,'style','push','pos',[300,20,60,24],...
    'string','Cancel','call','global SC_FLAG,SC_FLAG=-1;')
set(fig2,'vis','on')
global SC_FLAG
SC_FLAG = 0;
while ~SC_FLAG
  drawnow
end
flag = SC_FLAG;
clear global SC_FLAG

if flag > 0
  for j=1:nvar
    x = eval(get(ui(j),'string'),'[]');
    eval(sprintf('x%d=x;',j))
  end
end

delete(fig2)


function make_widgets(fig)

% Create uicontrol frames
bgcolor = .7*[1 1 1];
set(fig,'defaultuicontrolbackground',bgcolor,'defaultuicontrolunits','point')

% We aren't going to set positions, because that is done in resize_widgets
frame(1) = uicontrol('style','frame','tag','ui_settings');
frame(2) = uicontrol('style','frame','tag','ui_actions');

% Auto-generated by MATLAB's GUIDE, with some modifications

widget(1) = uicontrol('Parent',fig, ...
	'String','Monitor progress', ...
	'Style','checkbox', ...
	'Tag','trace', ...
	'Value',1);
widget(2) = uicontrol('Parent',fig, ...
	'FontWeight','bold', ...
	'String','Tolerance desired', ...
	'Horizontal','center',...
	'Style','text');
widget(3) = uicontrol('Parent',fig, ...
	'String','1e-5', ...
	'Background',.8*[1 1 1],...
	'Style','edit', ...
	'Tag','tol');
widget(4) = uicontrol('Parent',fig, ...
	'HorizontalAlignment','left', ...
	'Min',1, ...
	'FontWeight','bold', ...
	'String','Canonical domain', ...
	'Style','text', ...
	'Value',1);
mapname = {'disk','half-plane','strip','rectangle','disk exterior', ...
    'disk (CR)','rectified (CR)'};
widget(5) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''domain'');', ...
	'Max',7, ...
	'Min',1, ...
	'String',mapname, ...
	'Style','popupmenu', ...
	'Tag','domain', ...
	'Value',1);
widget(6) = uicontrol('Parent',fig, ...
	'HorizontalAlignment','left', ...
	'Min',1, ...
	'FontWeight','bold', ...
	'String','View', ...
	'Style','text', ...
	'Value',1);
widget(7) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''view'');', ...
	'Max',3, ...
	'Min',1, ...
	'String',{'Physical domain' 'Canonical domain' 'Both domains'}, ...
	'Style','popupmenu', ...
	'Tag','viewdomain', ...
	'Value',1);
widget(8) = uicontrol('Parent',fig, ...
	'HorizontalAlignment','right', ...
	'String','theta =', ...
	'Style','text', ...
	'Tag','YTtext');
widget(9) = uicontrol('Parent',fig, ...
	'String','defaults', ...
	'Background',.8*[1 1 1],...
	'Style','edit', ...
	'Tag','YT');
widget(10) = uicontrol('Parent',fig, ...
	'HorizontalAlignment','right', ...
	'String','r =', ...
	'Style','text', ...
	'Tag','XRtext');
widget(11) = uicontrol('Parent',fig, ...
	'String','defaults', ...
	'Style','edit', ...
	'Background',.8*[1 1 1],...
	'Tag','XR');
widget(12) = uicontrol('Parent',fig, ...
	'HorizontalAlignment','left', ...
	'FontWeight','bold', ...
	'String','Mesh lines', ...
	'Style','text');
    
widget(13) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''quit'');', ...
	'String','Quit');
widget(14) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''importexport'');', ...
	'String','Import/Export');
widget(15) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''editpts'');', ...
	'String','Edit points');
widget(16) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''plot'');', ...
	'String','Plot mesh');
widget(17) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''display'');', ...
	'String','Display');
widget(18) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''center'');', ...
	'String','Set center');
widget(19) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''solve'');', ...
	'String','Find parameters');
widget(20) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''edit'');', ...
	'String','Edit vertices');
widget(21) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''modify'');', ...
	'String','Modify');
widget(22) = uicontrol('Parent',fig, ...
	'Callback','scgui(gcf,''draw'');', ...
	'String','Draw');
widget(23) = uicontrol('Parent',fig, ...
        'HorizontalAlignment','center', ...
	'FontWeight','bold', ...
	'String','Polygon', ...
	'Style','text');
widget(24) = uicontrol('Parent',fig, ...
        'HorizontalAlignment','center', ...
	'FontWeight','bold', ...
	'String','Map', ...
	'Style','text');

set(frame(1),'userdata',widget(1:12))
set(frame(2),'userdata',widget(13:24))
setuprop(fig,'uihandles',[frame(:);widget(:)])

function resize_widgets(fig)
% This function is called whenever the figure is resized.

set(fig,'unit','point')
figpos = get(fig,'pos');

% Frames
f(1) = findobj(fig,'tag','ui_settings');
f(2) = findobj(fig,'tag','ui_actions');

% Minimum sizes
figpos(3) = max(figpos(3),418);
figpos(4) = max(figpos(4),334);

set(fig,'pos',figpos)
set(f,{'pos'},{[0 0 figpos(3) 72];[figpos(3)-80 72 80 figpos(4)-72]})

% Axes
ax(1) = findobj(fig,'tag','phydomain');
ax(2) = findobj(fig,'tag','candomain');
% Axes area needs a border of at least 32 pt on each side
usable = figpos(3:4) - [80 72];
setuprop(fig,'axeswindow',[32 104 usable-64]);

% Settings
h = get(f(1),'userdata');
pos = {
[2 4 110 18];...
[7 54 100 14];...
[33 34 48 18];...
[128 54 84 14];...
[128 38 84 18];...
[128 20 30 14];...
[128 4 108 18];...
[244 18 32 14];...
[276 18 140 16];...
[244 38 32 14];...
[276 38 140 16];...
[276 54 100 14]
};
set(h,{'pos'},pos)

% Actions
offset = [figpos(3)-76 figpos(4)-262 0 0];
h = get(f(2),'userdata');
pos = {
[0  0 72 18]+offset;...
[0 20 72 18]+offset;...
[0 40 72 18]+offset;...
[0 80 72 18]+offset;...
[0 100 72 18]+offset;...
[0 120 72 18]+offset;...
[0 140 72 18]+offset;...
[0 186 72 18]+offset;...
[0 206 72 18]+offset;...
[0 226 72 18]+offset;...
[14 246 44 12]+offset;...
[24 160 24 12]+offset
};
set(h,{'pos'},pos)

scgui(fig,'view');


function fig = make_importexportfig()

fig = figure('vis','off','number','off','name','Import/Export',...
    'tag','sc_importexport','handlevisibility','callback',...
    'unit','point','menu',menubar,'integerhandle','off');
pos = get(fig,'pos');
set(fig,'pos',[pos(1),pos(2),168,168])

uicontrol(fig,'style','frame','unit','point','pos',[0,0,168,168]);

uicontrol('Parent',fig, ...
	'Units','points', ...
	'FontWeight','bold', ...
	'Position',[16.9412 144.235 41.5059 16.0941], ...
	'String','Quantity', ...
	'Style','text');
uicontrol('Parent',fig, ...
	'Units','points', ...
	'FontWeight','bold', ...
	'Position',[66.0706 144.235 100.8 16.0941], ...
	'String','Variable Name', ...
	'Style','text');

uicontrol('Parent',fig, ...
	'Units','points', ...
	'HorizontalAlignment','left', ...
	'Position',[16.9412 116.282 76.2353 20.3294], ...
	'String','Polygon', ...
	'Style','text');
uicontrol('Parent',fig, ...
	'Units','points', ...
	'Position',[96.5647 121.365 42.3529 20.3294], ...
	'String','', ...
	'background',.8*[1 1 1],...
	'Style','edit', ...
	'Tag','pol');
uicontrol('Parent',fig, ...
	'Units','points', ...
	'HorizontalAlignment','left', ...
	'Position',[16.9412 90.0235 76.2353 20.3294], ...
	'String','Map', ...
	'Style','text');
uicontrol('Parent',fig, ...
	'Units','points', ...
	'Position',[96.5647 95.1059 41.5059 20.3294], ...
	'String','', ...
	'Style','edit', ...
	'Background',.8*[1 1 1],...
	'Tag','map');
uicontrol('Parent',fig, ...
	'Units','points', ...
	'HorizontalAlignment','left', ...
	'Position',[16.9412 63.7647 76.2353 20.3294], ...
	'String','Physical points', ...
	'Style','text');
uicontrol('Parent',fig, ...
	'Units','points', ...
	'Position',[96.5647 68.8471 41.5059 20.3294], ...
	'String','', ...
	'Background',.8*[1 1 1],...
	'Style','edit', ...
	'Tag','phy');
uicontrol('Parent',fig, ...
	'Units','points', ...
	'HorizontalAlignment','left', ...
	'Position',[16.9412 37.5059 76.2353 20.3294], ...
	'String','Canonical points', ...
	'Style','text');
uicontrol('Parent',fig, ...
	'Units','points', ...
	'Position',[96.5647 42.5882 41.5059 20.3294], ...
	'String','', ...
	'Background',.8*[1 1 1],...
	'Style','edit', ...
	'Tag','can');

% These buttons cause the actions to be taken
cb = ['fig=gcf; scfig = getuprop(fig,''scfig'');',...
      'data = scgimprt(getuprop(scfig,''mapdata''));,',...
      'setuprop(scfig,''mapdata'',data),',...
      'scgui(scfig,''importupdate'');',...
      'uiresume(fig)'];
uicontrol('Parent',fig, ...
	'Units','points', ...
	'Callback',cb, ...
	'Position',[5.08235 7.62353 50.8235 20.3294], ...
	'String','Import');
cb = ['scfig = getuprop(gcf,''scfig'');',...
      'scgexprt(getuprop(scfig,''mapdata'')),',...
      'uiresume(gcf)'];
uicontrol('Parent',fig, ...
	'Units','points', ...
	'Callback', cb, ...
	'Position',[58.9059 7.62353 51.6706 20.3294], ...
	'String','Export');
uicontrol('Parent',fig, ...
	'Units','points', ...
	'Callback','uiresume(gcf)', ...
	'Position',[113.576 7.62353 50.8235 20.3294], ...
	'String','Cancel');

