function zdot = hpimapfun(wp,yp,flag,scale,z,beta,c);
%   Used by HPINVMAP for solution of an ODE.

%   Copyright 1998 by Toby Driscoll.
%   $Id: hpimapfun.m,v 2.1 1998/05/10 04:45:35 tad Exp $

lenyp = length(yp);
lenzp = lenyp/2;
zp = yp(1:lenzp)+sqrt(-1)*yp(lenzp+1:lenyp);

f = scale./hpderiv(zp,z,beta,c);
zdot = [real(f);imag(f)];
