function display(M)
%DISPLAY Display parameters of a Schwarz-Christoffel exterior map.

%   Copyright 1998 by Toby Driscoll.
%   $Id: display.m,v 2.2 1998/07/01 17:43:58 tad Exp $

p = polygon(M);
w = vertex(p);
alpha = angle(p);
n = length(w);
z = flipud(M.prevertex);
c = M.constant;

fprintf('\n  extermap object:\n')
disp(' ')
disp('      vertex              alpha         prevertex             arg/pi')
disp(' -----------------------------------------------------------------------')
u = real(w);
v = imag(w);
x = real(z);
y = imag(z);
ang = angle(z)/pi;
ang(ang<=0) = ang(ang<=0) + 2;
for j = 1:length(w)
  if v(j) < 0
    s1 = '-';
  else
    s1 = '+';
  end
  if y(j) < 0
    s2 = '-';
  else
    s2 = '+';
  end
  disp(sprintf(' %8.5f %c %7.5fi    %8.5f   %8.5f %c %7.5fi    %14.12f',...
      u(j),s1,abs(v(j)),alpha(j),x(j),s2,abs(y(j)),ang(j)));
  
end
disp(' ')
if imag(c) < 0
  s = '-';
else
  s = '+';
end
fprintf('  c = %.8g %c %.8gi',real(c),s,abs(imag(c)))
fprintf('           Apparent accuracy = %.2e\n',M.accuracy)
fprintf('  Logarithmic capacity = %.8g\n\n',abs(c))