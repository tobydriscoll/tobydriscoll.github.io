function display(M)
%DISPLAY Display parameters of a Schwarz-Christoffel half-plane map.

%   Copyright 1998 by Toby Driscoll.
%   $Id: display.m,v 2.1 1998/05/10 04:16:33 tad Exp $

p = polygon(M);
w = vertex(p);
alpha = angle(p);
z = M.prevertex;
c = M.constant;

if length(z) < length(w)
  z = [z(:);Inf];
end
fprintf('\n  hplmap object:\n')
disp(' ')
disp('      vertex               alpha         prevertex       ')
disp(' --------------------------------------------------------')
u = real(w);
v = imag(w);
for j = 1:length(w)
  if v(j) < 0
    s = '-';
  else
    s = '+';
  end
  disp(sprintf(' %8.5f %c %7.5fi     %8.5f    %20.12e',...
      u(j),s,abs(v(j)),alpha(j),z(j)));
end
disp(' ')
if imag(c) < 0
  s = '-';
else
  s = '+';
end
fprintf('  c = %.8g %c %.8gi',real(c),s,abs(imag(c)))
fprintf('           Apparent accuracy = %.2e\n\n',M.accuracy)
