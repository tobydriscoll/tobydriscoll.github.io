function opt = options(M)
%OPTIONS Returns an options structure for the given SC map.

%   Copyright 2003 by Toby Driscoll.
%   $Id: options.m,v 1.1 2003/01/15 15:49:10 driscoll Exp $

opt = M.options;
