function display(f)

% $Id: display.m,v 1.2 2001/07/20 13:46:12 driscoll Exp $ 

fprintf('\n%s =\n',inputname(1))
disp(f)
