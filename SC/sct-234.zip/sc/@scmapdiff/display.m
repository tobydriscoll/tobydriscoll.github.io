function display(df)

fprintf('\n%s = Derivative of:\n',inputname(1))
disp(df.themap)
