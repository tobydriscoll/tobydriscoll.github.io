function disp(fi)

fprintf('\n  Inverse of:\n',inputname(1))
disp(fi.themap)