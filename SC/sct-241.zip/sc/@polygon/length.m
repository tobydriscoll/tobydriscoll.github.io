function n = length(p)
%   Returns number of vertices

%   Copyright 1998 by Toby Driscoll.
%   $Id: length.m 298 2009-09-15 14:36:37Z driscoll $

n = length(p.vertex);
