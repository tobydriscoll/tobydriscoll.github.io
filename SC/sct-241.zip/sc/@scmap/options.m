function opt = options(M)
%OPTIONS Returns an options structure for the given SC map.

%   Copyright 2003 by Toby Driscoll.
%   $Id: options.m 298 2009-09-15 14:36:37Z driscoll $

opt = M.options;
