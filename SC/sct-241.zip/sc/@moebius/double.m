function c = double(map)
%   Returns coefficients of the Moebius transformation.

%   Copyright (c) 1998 by Toby Driscoll.
%   $Id: double.m 298 2009-09-15 14:36:37Z driscoll $

c = map.coeff;