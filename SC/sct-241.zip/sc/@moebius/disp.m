function disp(f)

disp(char(f))