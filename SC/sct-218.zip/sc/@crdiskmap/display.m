function display(M)
%DISPLAY Display parameters of a Schwarz-Christoffel crossratio disk map.

%   Copyright 1998 by Toby Driscoll.
%   $Id: display.m,v 2.1 1998/05/10 04:03:45 tad Exp $

p = polygon(M);
w = vertex(p);
beta = angle(p)-1;
cr = M.crossratio;
Q = M.qlgraph;

fprintf('\n  crdiskmap object:\n')
disp(' ')
disp('   Quadrilateral vertices        Prevertex crossratio  ')
disp(' ------------------------------------------------------')
for j = 1:length(cr)
  fprintf('      %2i  %2i  %2i  %2i                   %8.5f\n',...
      Q.qlvert(:,j),cr(j));
end
wc = center(M);
if imag(wc) < 0
  s = '-';
else
  s = '+';
end
disp(' ')
fprintf('   Conformal center at %.4f %c %.4fi\n',real(wc),s,abs(imag(wc)))
fprintf('   Apparent accuracy = %.2e\n\n',M.accuracy)
