function K = scselect(w,beta,m)
%SCSELECT Select one or more vertices in a polygon.
%   K = SCSELECT(W,BETA,M) draws the polygon given by W and BETA into
%   the current figure window and then allows the user to select M
%   vertices using the mouse.  If M is not given, it defaults to 1.  On
%   exit K is a vector of indices into W.
%
%   See also DRAWPOLY, PLOTPOLY, MODPOLY.

%   Copyright 1998 by Toby Driscoll.
%   $Id: scselect.m,v 2.1 1998/05/10 04:54:02 tad Exp $

n = length(w);
if any(isinf(w) & isinf(w([2:n,1])))
  error('Infinite vertices must not be adjacent')
end

[ehan,lhan] = plotpoly(w,beta,1);
turn_off_hold = ~ishold;
hold on

h = lhan;
colors = get(gca,'colororder');
if colors(1,1) > colors(1,3)
  hilit = [0 0 1];
else
  hilit = [1 0 0];
end

oldptr = get(gcf,'pointer');
set(gcf,'pointer','circle');

if nargin < 3
  m = 1;
end

% Begin selection(s)
figure(gcf)
for j = 1:m
  k = [];
  while isempty(k)
    waitforbuttonpress;
    obj = get(gcf,'currentobj');
    [k,tmp] = find(obj==h);
    if isempty(k)
      disp('Selected object not a vertex.  Try again.')
    end
  end
  set(h(k,:),'color',hilit)
  drawnow
  K(j) = k;
end
set(gcf,'pointer',oldptr)

% Clean up
delete(h)
drawnow
if turn_off_hold
  hold off
end 
