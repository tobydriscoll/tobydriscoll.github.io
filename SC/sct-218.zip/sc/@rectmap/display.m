function display(M)
%DISPLAY Display parameters of a Schwarz-Christoffel rectangle map.

%   Copyright 1998 by Toby Driscoll.
%   $Id: display.m,v 2.1 1998/05/10 04:21:21 tad Exp $

p = polygon(M);
w = vertex(p);
alpha = angle(p);
z = M.prevertex;
c = M.constant;

n = length(w);
% Deduce corner locations
left = abs(real(z)-min(real(z))) < eps;
right = abs(real(z)-max(real(z))) < eps;
top = abs(imag(z)-max(imag(z))) < eps;
bot = abs(imag(z)-min(imag(z))) < eps;
corners = find(left+right+top+bot - 1);
c1 = find(abs(z-max(real(z))) < eps);
offset = find(corners==c1);
corners = corners([offset:4,1:offset-1]);
rect = z(corners);

fprintf('\n  rectmap object:\n')
disp(' ')
disp(' cnr      vertex              alpha               prevertex       ')
disp(' ------------------------------------------------------------------------')
u = real(w);
v = imag(w);
for j = 1:length(w)
  if v(j) < 0
    s = '-';
  else
    s = '+';
  end
  cnr = find(j==corners);
  if isempty(cnr)
    cstr = '    ';
  else
    cstr = sprintf('  %i ',cnr);
  end
  if ~imag(z(j))
    disp(sprintf('%s %8.5f %c %7.5fi    %8.5f   %16.8e',...
      cstr,u(j),s,abs(v(j)),alpha(j),z(j)));
  else
    disp(sprintf('%s %8.5f %c %7.5fi    %8.5f   %16.8e + %14.8ei',...
      cstr,u(j),s,abs(v(j)),alpha(j),real(z(j)),imag(z(j))));
  end    
end
disp(' ')
if imag(c) < 0
  s = '-';
else
  s = '+';
end
fprintf('  c = %.8g %c %.8gi',real(c),s,abs(imag(c)))
fprintf('           Apparent accuracy = %.2e\n',M.accuracy)

fprintf('  Conformal modulus = %.8g\n\n',imag(rect(2))/rect(1)/2)

