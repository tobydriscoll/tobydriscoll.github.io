function z = linspace(p,n)
%LINSPACE Evenly spaced points around the polygon.
%   LINSPACE(P,N) returns a vector of N points evenly spaced on the
%   polygon P, starting with the first vertex.

%   Copyright 1998 by Toby Driscoll. 
%   $Id: linspace.m,v 2.1 1998/05/10 03:44:01 tad Exp $

m = length(p);
w = vertex(p);
% Arc lengths of sides
dw = diff(w([1:m 1]));
s = abs(dw);
s = cumsum([0;s]);
s = s/s(m+1);

% Evenly spaced points in arc length
zs = (0:n-1)'/n;
z = zs;
done = logical(zeros(size(z)));

% Translate to polygon sides
for j = 1:m
  mask = (~done) & (zs < s(j+1));
  z(mask) = w(j) + dw(j)*(zs(mask)-s(j))/(s(j+1)-s(j));
  done = mask | done;
end

if any(~done) 
  error
end
