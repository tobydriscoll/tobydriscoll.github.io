function display(p)
%   Show the polygon as a list of vertices in (x,y) form.
%   Copyright 1998 by Toby Driscoll.
%   $Id: display.m,v 2.1 1998/05/10 03:51:17 tad Exp $

w = p.vertex;
n = length(w);

fprintf('\n%s = \n\n',inputname(1))
if n > 0
  disp([real(w) imag(w)])
else 
  fprintf('     []\n\n')
end
