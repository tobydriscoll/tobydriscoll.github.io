function Md = scmapdiff(M)
%SCMAPDIFF Derivative of a Schwarz-Christoffel map.
%   SCMAPDIFF(M) returns a dummy object that represents the derivative
%   of the SC map M. The only thing possible with this object is to EVAL
%   it.
%   
%   See also SCMAPDIFF/EVAL, SCMAPDIFF/SUBSREF.

%   Copyright 1998 by Toby Driscoll.
%   $Id: scmapdiff.m,v 2.1 1998/05/10 04:25:09 tad Exp $

Md.themap = M;
Md = class(Md,'scmapdiff');
