% Schwarz-Christoffel Toolbox
% Version 2.1   Feb 21, 2001
% Copyright (c) 1998-2001 by Toby Driscoll (driscoll@math.udel.edu).
% See user's guide for full usage details.
%
%   scdemo     - Select demos from a menu.
%   scgui      - Activate graphical user interface.
% 
% Polygons.
%   polygon    - Create a polygon object from vertices and angles.
%   drawpoly   - Draw a polygon with the mouse.
%   plot       - Plot a polygon.
%   display    - Show vertices.
%   cdt        - Constrained Delaunay triangulation of vertices.
%   plotcdt    - Plot a CDT.
%   vertex     - Retrieve vertices.
%   angle      - Retrieve normalized angles.
%   modify     - Modify vertices using the mouse.
%   length     - Number of vertices.
%   + *        - Translate or scale.
%   (...)      - Reference or assign one or more vertices.
% 
% Map types.
%   diskmap    - Disk -> polygon.
%   extermap   - Disk -> polygon exterior.
%   hplmap     - Half-plane -> polygon.
%   stripmap   - Strip -> polygon.
%   rectmap    - Rectangle -> generalized quadrilateral.
%   crdiskmap  - Disk -> polygon, in cross-ratio formulation.
%   crrectmap  - Rectilinear polygon -> polygon, using cross-ratios.
% 
% Map operations.
%   display    - Show salient data.
%   polygon    - Retrieve the target polygon.
%   parameters - Retrieve a structure of map parameters.
%   accuracy   - Approximate max-norm accuracy.
%   eval       - Evaluate at point(s).
%   (...)      - Evaluate at point(s).
%   evalinv    - Evaluate inverse at point(s).
%   evaldiff   - Evaluate derivative at point(s).
%   plot       - Plot the image of an orthogonal grid under the map.
%   center     - Retrieve or set conformal center (disk maps only).
% 
% Utility routines.
%   scmapopt   - Set options for the parameter problem solution.
%   faber      - Compute Faber polynomials (of polygon or extermap).
%   moebius    - Moebius transformation parameters.
