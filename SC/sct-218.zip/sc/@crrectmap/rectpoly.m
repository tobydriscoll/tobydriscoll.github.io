function pr = rectpoly(M)
%   Return rectified polygon.

%   Copyright 1998 by Toby Driscoll.
%   $Id: rectpoly.m,v 2.1 1998/05/10 04:10:03 tad Exp $

pr = M.rectpolygon;
