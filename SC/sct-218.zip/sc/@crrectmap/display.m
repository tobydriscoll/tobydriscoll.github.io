function display(M)
%DISPLAY Display parameters of a Schwarz-Christoffel CR rectified map.

%   Copyright 1998 by Toby Driscoll.
%   $Id: display.m,v 2.1 1998/05/10 04:08:52 tad Exp $

p = polygon(M);
w = vertex(p);
wr = vertex(M.rectpolygon);
alphar = angle(M.rectpolygon);

fprintf('\n  crrectmap object:\n')
disp(' ')
disp('      vertex          rectified angle        prevertex       ')
disp(' ------------------------------------------------------------')
u = real(w);
v = imag(w);
ur = real(wr);
vr = imag(wr);
sgn = ['-','+','+'];
s = sgn(sign(v)+2);
sr = sgn(sign(vr)+2);
for j = 1:length(w)
  fprintf(' %8.5f %c %7.5fi       %3.1f pi       %8.5f %c %7.5fi\n',...
      u(j),s(j),abs(v(j)),alphar(j),ur(j),sr(j),abs(vr(j)));
end
disp(' ')
fprintf('           Apparent accuracy = %.2e\n\n',accuracy(M))
