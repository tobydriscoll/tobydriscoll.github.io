function display(M)
%DISPLAY Display parameters of a Schwarz-Christoffel strip map.

%   Copyright 1998 by Toby Driscoll.
%   $Id: display.m,v 2.1 1998/05/10 04:27:13 tad Exp $

p = polygon(M);
w = vertex(p);
alpha = angle(p);
z = M.prevertex;
c = M.constant;

fprintf('\n  stripmap object:\n')
disp(' ')
disp('      vertex               alpha           prevertex         ')
disp(' ------------------------------------------------------------')
u = real(w);
v = imag(w);
for j = 1:length(w)
  if v(j) < 0
    s = '-';
  else
    s = '+';
  end
  if ~imag(z(j))
    disp(sprintf(' %8.5f %c %7.5fi     %8.5f    %20.12e',...
      u(j),s,abs(v(j)),alpha(j),z(j)));
  else
    disp(sprintf(' %8.5f %c %7.5fi     %8.5f    %20.12e + i',...
      u(j),s,abs(v(j)),alpha(j),z(j)));
  end    
end
disp(' ')
if imag(c) < 0
  s = '-';
else
  s = '+';
end
disp(sprintf('  c = %.8g %c %.8gi',real(c),s,abs(imag(c))))
fprintf('           Apparent accuracy = %.2e\n\n',M.accuracy)
