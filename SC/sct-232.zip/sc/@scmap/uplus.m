function M = uplus(M)
