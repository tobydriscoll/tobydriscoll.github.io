function M = uminus(M)
%   Negate the image of an SC map.

%   Copyright (c) 1998 by Toby Driscoll.
%   $Id: uminus.m,v 1.1 1998/07/01 20:18:31 tad Exp $

M = (-1)*M;