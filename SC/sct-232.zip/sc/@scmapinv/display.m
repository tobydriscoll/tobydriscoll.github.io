function display(fi)

fprintf('\n%s = Inverse of:\n',inputname(1))
disp(fi.themap)
