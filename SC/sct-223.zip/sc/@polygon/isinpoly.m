function idx = isinpoly(wc,p)

%   Copyright 1998 by Toby Driscoll.
%   $Id: isinpoly.m,v 2.1 1998/05/10 03:53:03 tad Exp $
if any(isinf(p.vertex))
  error('Cannot detect interior of an unbounded polygon.')
end
idx = isinpoly(wc,p.vertex);
