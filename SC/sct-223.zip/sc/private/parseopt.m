function varargout =  parseopt(options)

%   Copyright 1998--2001 by Toby Driscoll.
%   $Id: parseopt.m,v 1.3 2001/05/07 14:53:13 driscoll Exp $

% There are 2 allowable inputs: old-fashioned array and newfangled
% structure. Handle both here.

if ~isstruct(options)
  user = options;
  lenu = length(user);
  options = zeros(1,3);
  options(1:lenu) = user(1:lenu);
  options = options + (options==0).*[0,1e-8,2];
  
  trace = options(1);
  tol = options(2);
  method = options(3);
  varargout = { trace,tol,method };
else
  trace = strcmp(options.TraceSolution,'on');
  tol = options.Tolerance;
  method = strmatch(options.SolverMethod,{'line','trust'});
  %%newwindow = strcmp(options.WindowPopup,'on');
  varargout = { trace, tol, method };
end
