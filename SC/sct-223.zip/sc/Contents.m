% Schwarz-Christoffel Toolbox
% Version 2.2.1   July 20, 2001
% Copyright (c) 1994-2001 by Toby Driscoll (driscoll@math.udel.edu).
% See the user's guide for full usage details.
%
%   scdemo     - Select demos from a menu.
%   scgui      - Activate graphical user interface.
% 
% Polygons.
%   polygon    - Create a polygon object from vertices and angles.
%   polyedit   - Draw & edit a polygon with the mouse.
%   plot       - Plot a polygon.
%   display    - Show vertices.
%   cdt        - Constrained Delaunay triangulation of vertices.
%   plotcdt    - Plot a CDT.
%   vertex     - Retrieve vertices.
%   angle      - Retrieve normalized angles.
%   length     - Number of vertices.
%   + *        - Translate or scale.
%   (...)      - Reference or assign one or more vertices.
% 
% SC map types.
%   diskmap    - Disk -> polygon.
%   extermap   - Disk -> polygon exterior.
%   hplmap     - Half-plane -> polygon.
%   stripmap   - Strip -> polygon.
%   rectmap    - Rectangle -> generalized quadrilateral.
%   crdiskmap  - Disk -> polygon, in cross-ratio formulation.
%   crrectmap  - Rectilinear polygon -> polygon, using cross-ratios.
% 
% Map operations.
%   display    - Show map parameters.
%   eval       - Evaluate at point(s).
%   (...)      - Evaluate at point(s).
%   evalinv    - Evaluate inverse at point(s).
%   evaldiff   - Evaluate derivative at point(s).
%   plot       - Plot the image of an orthogonal grid under the map.
%   center     - Retrieve or set conformal center (disk maps only).
%   polygon    - Retrieve the target polygon.
%   parameters - Retrieve a structure of map parameters.
%   accuracy   - Approximate max-norm accuracy.
% 
% Utility routines.
%   scmapopt   - Set options for the parameter problem solution.
%   faber      - Compute Faber polynomials (of a polygon or extermap).
%   moebius    - Define a Moebius transformation.
%   composite  - Define a composition of maps.
