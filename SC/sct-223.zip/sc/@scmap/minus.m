function M = minus(M,a)
%   Subtract a contant from the image of an SC map.

%   Copyright (c) 1998 by Toby Driscoll.
%   $Id: minus.m,v 1.1 1998/07/01 20:19:28 tad Exp $

M = M + (-a);

