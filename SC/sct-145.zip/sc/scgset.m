function scgset(fig,p1,v1,p2,v2,p3,v3,p4,v4,p5,v5)
%SCGSET Set data in the SCM Toolbox GUI.
%	SCGSET(FIG,'property',VALUE) sets the value of the specified
%	property to VALUE in the Schwarz-Christoffel Mapping Toolbox GUI in
%	igure FIG.  Valid properties are:
%	
%	   vertices    (polygon vertices)
%	   angles      (turning angles)
%	   prevertices (solution of parameter problem)
%	   constant    (multiplicative constant and rectangle L)
%	   maptype     ('disk','half-plane','strip','rectangle','exterior')
%          phypoints   (points in physical domain)
%          canpoints   (points in canonical domain)
%	
%	Only the first three characters of a property name need be
%	specified.  If additional property name-value pairs are given, they
%	will be set appropriately. 
%	
%	SCGSET(FIG,'clear') removes all data associated with the GUI.
%
%	See also SCGGET, SCGUI.
%	
%	Copyright 1996 by Toby Driscoll.  Last updated 5/26/95.

maptypes = str2mat('disk','half-plane','strip','rectangle','exterior');

if (nargin==2) & strcmp(lower(p1),'clear')
  set(fig,'userdata',[]);
  set(findobj(fig,'tag','phypoints'),'xdata',[],'ydata',[])
  set(findobj(fig,'tag','canpoints'),'xdata',[],'ydata',[])
  return
end

if rem(nargin,2) ~= 1
  error('Wrong number of input parameters.')
end
data = get(fig,'userdata');

for k = 1:(nargin-1)/2
  prop = eval(['p',int2str(k)]);
  if ~isstr(prop)
    error('Property name expected.')
  else
    prop = lower(prop);
  end
  val = eval(['v',int2str(k)]);
  if isempty(val) & ~isempty(data)
    if strcmp(prop(1:3),'con')  
      val = [0;0];
    elseif strcmp(prop(1:3),'map')
      val = 0;
    elseif strcmp(prop(1:3),'ver') | strcmp(prop(1:3),'ang') | ...
	  strcmp(prop(1:3),'pre')
      val = zeros(size(data(:,1)));
    end
  end
      
  if strcmp(prop(1:3),'ver')
    if length(val(:)) ~= size(data,1);
      % If vertices can't be replaced one-for-one, other data is useless. 
      data = [];
    end
    data(1:length(val),1) = val(:);
  elseif strcmp(prop(1:3),'ang')
    data(1:length(val),2) = val(:);
  elseif strcmp(prop(1:3),'pre')
    data(1:length(val),3) = val(:);
  elseif strcmp(prop(1:3),'con')
    data(1:length(val),4) = val;
  elseif strcmp(prop(1:3),'ell')
    data(2,4) = val;
  elseif strcmp(prop(1:3),'map')
    if isstr(val)
      found = 0;
      [m,n] = size(maptypes);
      for j = 1:m
	if strcmp(lower(val),deblank(maptypes(j,:)))
	  data(1,5) = j;
	  found = 1;
	  break
	end
      end
      if ~found & ~isempty(val)
	error(['Map type ',val,' unknown.'])
      end
    else
      if val > -1 & val < 6
	data(1,5) = val;
      elseif ~isempty(val)
	error(sprintf('Map number %d unknown.',val))
      end
    end
  elseif strcmp(prop(1:3),'phy')
    set(findobj(fig,'tag','phypoints'),'xdata',real(val),'ydata',imag(val))
  elseif strcmp(prop(1:3),'can')
    set(findobj(fig,'tag','canpoints'),'xdata',real(val),'ydata',imag(val))
    
  else
    error(['Property ',prop,' unknown.'])
  end
end

set(fig,'userdata',data);

