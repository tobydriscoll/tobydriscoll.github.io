function [H,RE,IM] = hpplot(w,beta,z,c,re,im,options)
%HPPLOT Image of cartesian grid under Schwarz-Christoffel half-plane map.
%       HPPLOT(W,BETA,Z,C) will adaptively plot the images under the
%       Schwarz-Christoffel exterior map of ten evenly spaced horizontal
%       and vertical lines in the upper half-plane. The abscissae of the
%       vertical lines will bracket the finite extremes of Z.  The
%       arguments are as in HPPARAM.
%
%       HPPLOT(W,BETA,Z,C,M,N) will plot images of M evenly spaced
%       vertical and N evenly spaced horizontal lines.  The spacing will
%       be the same in both directions.
%
%       HPPLOT(W,BETA,Z,C,RE,IM) will plot images of vertical lines
%       whose real parts are given in RE and horizontal lines whose
%       imaginary parts are given in IM.  Either argument may be empty.
%
%       HPPLOT(W,BETA,Z,C,RE,IM,OPTIONS) allows customization of
%       HPPLOT's behavior.  See SCPLTOPT.
%
%       H = HPPLOT(W,BETA,Z,C,...) returns a vector of handles to all
%       the curves drawn in the interior of the polygon.  [H,RE,IM] =
%       HPPLOT(W,BETA,Z,C,...) also returns the abscissae and ordinates
%       of the lines comprising the grid.
%	
%	See also SCPLTOPT, HPPARAM, HPMAP, HPDISP.
%
%	Copyright 1996 by Toby Driscoll.  Last updated 11/13/96.

turn_off_hold = ~ishold;
n = length(w);
w = w(:);
beta = beta(:);
z = z(:);
if nargin < 7
  options = [];
  if nargin < 6
    im = [];
    if nargin < 5
      re = [];
    end
  end
end

if isempty([re(:);im(:)])
  re = 10;
  im = 10;
end

if (length(re)==1) & (re == round(re))
  if re < 1
    re = [];
  elseif re < 2
    re = mean(z([1,n-1]));
  else
    m = re;
    re = linspace(z(1),z(n-1),m);
    dre = diff(re(1:2));
    re = linspace(z(1)-dre,z(n-1)+dre,m);
  end
end
if (length(im)==1) & (im == round(im))
  if length(re) < 2
    im = linspace(0,4,im+1);
    im(1) = [];
  else
    im = mean(diff(re))*(1:im);
  end
end

[nqpts,maxturn,maxlen,maxrefn] = scpltopt(options);

fig = gcf;
figure(fig);
plotpoly(w,beta);
drawnow
hold on

n = length(w);
reflen = maxlen*max(abs(diff([w(~isinf(w));w(1)])));
if any(isinf(z))
  qdat = scqdata(beta(1:n-1),nqpts);
else
  qdat = scqdata(beta,nqpts);
end

y2 = max(z(n-1),10);
emode = 'normal';
if strcmp(computer,'PCWIN')
  % Odd bug in erasemode in Windows
  emode = 'back';
end
for j = 1:length(re)
  zp = re(j) + i*linspace(0,y2,15).';
  wp = hpmap(zp,w,beta,z,c,qdat);
  bad = find(toobig([wp;w(n)],maxturn,reflen,axis));
  iter = 0;
  while (~isempty(bad)) & (iter < maxrefn)
    lenwp = length(wp);
    newz = [];
    special = find(bad==lenwp);
    newz = re(j) + i*5*imag(zp(bad(special)));
    bad(special) = [];
    newz = [newz;(zp(bad-1)+2*zp(bad))/3;(zp(bad+1)+2*zp(bad))/3];
    neww = hpmap(newz,w,beta,z,c,qdat);
    [k,in] = sort(imag([zp;newz]));
    zp = [zp;newz];  wp = [wp;neww];
    zp = zp(in);     wp = wp(in);
    iter = iter + 1;
    bad = find(toobig([wp;w(n)],maxturn,reflen,axis));
  end
  linh(j) = plot(clipdata([wp;w(n)],axis), 'g-','erasemode','none');
  drawnow
  set(linh(j),'erasemode',emode);
  Z(1:length(zp),j) = zp;
  W(1:length(wp),j) = wp;
end

z1 = min(-10,z(n-1));
z2 = max(40,z(n-1));
axlim = axis;
for j = 1:length(im)
  zp = linspace(z1,z2,15).' + i*im(j);
  wp = hpmap(zp,w,beta,z,c,qdat);
  bad = find(toobig([w(n);wp;w(n)],maxturn,reflen,axis)) - 1;
  iter = 0;
  while (~isempty(bad)) & (iter < maxrefn)
    lenwp = length(wp);
    special = zeros(2,1);
    if isinf(w(n))
      ends = wp([1,lenwp]);
      special = real(ends)>axlim(1) & real(ends)<axlim(2) & ...
	  imag(ends)>axlim(3) & imag(ends)<axlim(4);
    else 
      special(1) = any(bad==1);
      special(2) = any(bad==lenwp);
    end
    bad(bad==1 | bad==lenwp) = [];
    newz = [(zp(bad-1)+2*zp(bad))/3;(zp(bad+1)+2*zp(bad))/3];
    zends = zp([1,lenwp]);
    newz = [newz;i*imag(zends(special))+5*real(zends(special))];
    neww = hpmap(newz,w,beta,z,c,qdat);
    [k,in] = sort(real([zp;newz]));
    zp = [zp;newz];  wp = [wp;neww];
    zp = zp(in);     wp = wp(in);
    iter = iter + 1;
    bad = find(toobig([w(n);wp;w(n)],maxturn,reflen,axis)) - 1;
  end
  linh(j+length(re)) = plot(clipdata([w(n);wp;w(n)],axis),...
      'g-','erasemode','none');
  drawnow
  set(linh(j+length(re)),'erasemode',emode);
  Z(1:length(zp),j+length(re)) = zp;
  W(1:length(wp),j+length(re)) = wp;
end
  
% Force redraw to get clipping enforced.
set(fig,'color',get(fig,'color'))
plot(NaN,NaN)
if turn_off_hold, hold off, end;
if nargout > 0
  H = linh;
  if nargout > 1
    RE = re;
    if nargout > 2
      IM = im;
    end
  end
end 

