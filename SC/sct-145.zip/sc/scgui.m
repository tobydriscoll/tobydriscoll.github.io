function out = scgui(fig,cmd,data)
%SCGUI  Create graphical user interface for SCM Toolbox.
%
%	By itself, SCGUI creates the graphical user interface (GUI)
%	menus for the Schwarz-Christoffel Toolbox in the current
%	figure window.
%
%	SCGUI(FIG) creates the GUI in figure window FIG.
%
%	Use of the GUI is straightforward.  For complete details, see
%	the user's guide.
%
%       See also SCGGET, SCGSET.
%
%	Copyright 1996 by Toby Driscoll.  Last updated 11/20/96.

% Supply default parameters
if nargin < 2
  cmd = '';
  if nargin < 1
    fig = figure;
  end
end

if isempty(cmd)
  % Original call (user's call)

  figure(fig)
  clf
  reset(fig)
  set(fig,'name','Schwarz-Christoffel')
  pos = get(fig,'pos');
  set(0,'unit','pix')
  maxpos = get(0,'screensize');
  
  % Add some at the bottom to make better axes aspect
  pos = pos + [0,-50,0,50];
  pos(4) = max(pos(4),375);
  set(fig,'pos',pos)
  
  % Create axes
  ax(1) = axes('units','pix','pos',[36,115,pos(3)-182,pos(4)-152],...
      'aspect',[1,1],'tag','phydomain');
  ax(2) = axes('units','pix','pos',[36,115,pos(3)-182,pos(4)-152],...
      'aspect',[1,1],'tag','candomain','vis','off');
  set(ax,'unit','norm','next','add','box','on')
  
  % Create uicontrol frames
  frame(1) = uicontrol('style','frame','pos',[0,0,maxpos(3),88],...
      'tag','settings');
  frame(2) = uicontrol('style','frame',...
      'pos',[pos(3)-128,88,128,pos(4)-88],'tag','actions');
  set(frame,'unit','norm')
  
  % Create widgets
  setting(1) = uicontrol(fig,'style','check','pos',[4,4,200,20],...
      'string','Monitor solution progress','tag','trace');
  setting(2) = uicontrol(fig,'style','text','pos',[4,32,150,20],...
      'string','Tolerance desired: 1e-','hor','left');
  setting(3) = uicontrol(fig,'style','edit','pos',[156,32,24,20],...
      'string','8','tag','tol');
  setting(4) = uicontrol(fig,'style','text','pos',[4,58,120,20],...
      'string','Canonical domain:','hor','left');
  setting(5) = uicontrol(fig,'style','pop','pos',[126,58,110,20],...
      'string','disk|half-plane|strip|rectangle|disk exterior',...
      'call','scgui(gcf,''domain'')','tag','domain');
  
  setting(6) = uicontrol(fig,'style','text','pos',[270,4,40,20],...
      'string','View: ','hor','r');
  setting(7) = uicontrol(fig,'style','pop','pos',[314,4,145,20],...
      'string','Physical domain|Canonical domain',...
      'call','scgui(gcf,''view'')','tag','viewdomain');
  setting(8) = uicontrol(fig,'style','text','pos',[310,32,55,20],...
      'string','theta = ','hor','r','tag','YTtext');
  setting(9) = uicontrol(fig,'style','edit','pos',[365,32,145,20],...
      'string','','tag','YT');
  setting(10) = uicontrol(fig,'style','text','pos',[310,58,55,20],...
      'string','r = ','hor','r','tag','XRtext');
  setting(11) = uicontrol(fig,'style','edit','pos',[365,58,145,20],...
      'string','','tag','XR');
  setting(12) = uicontrol(fig,'style','text','pos',[270,56,40,20],...
      'string','Mesh','hor','c');
  setting(13) = uicontrol(fig,'style','text','pos',[270,39,40,20],...
      'string','lines:','hor','c');
  
  x = pos(3)-128;
  y = 88 + max(0,pos(4)-88-320);
  set(fig','defaultuicontrolinterrupt','yes')
  action(1) = uicontrol(fig,'style','push','pos',[x+8,y,112,24],...
      'string','Quit','call',...
      'delete([findobj(0,''tag'',''sc_importexport'') gcf])');
  action(2) = uicontrol(fig,'style','push','pos',[x+8,y+32,112,24],...
      'string','Import/Export','call','scgui(gcf,''importexport'')');
  action(3) = uicontrol(fig,'style','push','pos',[x+8,y+64,112,24],...
      'string','Edit points','call','scgui(gcf,''editpts'')');
  action(4) = uicontrol(fig,'style','push','pos',[x+8,y+96,112,24],...
      'string','Plot mesh','call','scgui(gcf,''plot'')');
  action(5) = uicontrol(fig,'style','push','pos',[x+8,y+128,112,24],...
      'string','Display results','call','scgui(gcf,''display'')');
  action(6) = uicontrol(fig,'style','push','pos',[x+8,y+160,112,24],...
      'string','Set center','call','scgui(gcf,''center'')');
  action(7) = uicontrol(fig,'style','push','pos',[x+8,y+192,112,24],...
      'string','Solve','call','scgui(gcf,''solve'')');
  action(8) = uicontrol(fig,'style','push','pos',[x+8,y+226,112,24],...
      'string','Edit vertices','call','scgui(gcf,''edit'')');
  action(9) = uicontrol(fig,'style','push','pos',[x+8,y+258,112,24],...
      'string','Modify polygon','call','scgui(gcf,''modify'')');
  action(10) = uicontrol(fig,'style','push','pos',[x+8,y+290,112,24],...
      'string','Draw polygon','call','scgui(gcf,''draw'')');
  set(action,'unit','norm')

  set(frame(1),'user',setting)
  set(frame(2),'user',action)
  set(setting,'unit','norm')
  set(action,'unit','norm')
  
elseif strcmp(cmd,'draw')		%*** Draw button
  % Make physical domain visible
  ax(1) = findobj(fig,'tag','phydomain');
  ax(2) = findobj(fig,'tag','candomain');
  set(findobj(fig,'tag','viewdomain'),'value',1)
  scgui(fig,'view')

  set(ax(1),'buttondown','')		% turn off point mapping
  delete(findobj(ax(1),'tag','polygon'))
  phypoints = findobj(fig,'tag','phypoints');
  set(phypoints,'vis','off')
  meshlines = findobj(fig,'tag','meshlines');
  set(meshlines,'vis','off')
  axis auto
  uihandles = findobj(fig,'type','uicontrol');
  [w0,beta0] = scgget(fig,'ver','ang');
  set(uihandles,'vis','off')

  % If drawpoly dies, clear the figure's callbacks via error trap
  errfun = ['set(fig,''windowbuttondownfcn'',''''),',...
	'set(fig,''windowbuttonmotionfcn'',''''),',...
	'set(fig,''windowbuttonupfcn'',''''),',...
	'set(fig,''keypressfcn'',''''),',...
	'w=[];b=[];'];
  eval('[w,b,h] = drawpoly(fig);',errfun);

  set(uihandles,'vis','on')
  set(ax(1),'unit','norm','xgrid','off','ygrid','off')
  drawnow
  
  if ~isempty(w)			% do nothing if action canceled
    scgset(fig, 'clear');
    scgset(fig,'vertices',w,'angles',b)
    axes(ax(2))
    cla 
    axes(ax(1))
    delete(findobj(fig,'tag','meshlines'))
    delete(findobj(fig,'tag','phypoints'))
    scgui(fig,'domain')
  else
    h = plotpoly(w0,beta0);
    set(phypoints,'vis','on')
    set(meshlines,'vis','on')
  end
  set(h,'tag','polygon')
  
elseif strcmp(cmd,'modify')		%*** Modify button
  [w,beta] = scgget(fig,'ver','ang');
  if ~isempty(w) & ~isempty(beta)	% polygon must exist!
    n = length(w);
    ax(1) = findobj(fig,'tag','phydomain');
    ax(2) = findobj(fig,'tag','candomain');
    set(findobj(fig,'tag','viewdomain'),'value',1)
    scgui(fig,'view')
    
    set(ax(1),'buttondown','')		% turn off point mapping
    delete(findobj(ax(1),'tag','polygon'))
    phypoints = findobj(fig,'tag','phypoints');
    set(phypoints,'vis','off')
    meshlines = findobj(fig,'tag','meshlines');
    set(meshlines,'vis','off')
    uihandles = findobj(fig,'type','uicontrol');
    set(uihandles,'vis','off')

    axes(ax(1))
    [w1,beta1,idx] = modpoly(w,beta);

    set(uihandles,'vis','on')
    changed = 0;
    % Was anything really changed?
    if length(w1) ~= length(w)
      changed = 1;
    elseif norm(w(~isinf(w))-w1(~isinf(w1))) > 1000*eps
      changed = 1;
    end
    if changed
      scgset(fig,'vertices',w1,'angles',beta1)
      axes(ax(2))
      cla 
      axes(ax(1))
      cla 
      if any(isnan(idx)) | any(diff([0;idx;n+1])~=1)
	% Cannot use continuation if vertices were added/deleted.
	scgset(fig,'pre',[],'con',[])
      else
	% Flag that there is no current soln
	scgset(fig,'con',0)
      end
      scgui(fig,'domain')
    else
      % Status quo
      set(phypoints,'vis','on')
      set(meshlines,'vis','on')
    end
    axes(ax(1))
    h = plotpoly(w1,beta1);
    set(h,'tag','polygon')
  end

elseif strcmp(cmd,'edit')		%*** Edit button
  [w,beta] = scgget(fig,'ver','ang');
  if ~isempty(w)
    if any(isinf(w))
      fprintf('Cannot edit vertices of unbounded polygons.\n')
      return
    end
    n = length(w);
    
    % Call edit window
    [flag,w] = scgedit('Edit vertices','Vertices:',w);

    if flag > 0				% action was taken
      ax(1) = findobj(fig,'tag','phydomain');
      ax(2) = findobj(fig,'tag','candomain');
      axes(ax(2))
      cla 
      axes(ax(1))
      cla 
      beta = scangle(w);
      scgset(fig,'ver',w(:),'ang',beta(:),'con',0)
      if length(w)~=n
	scgset(fig,'pre',[])
      end
      set(findobj(fig,'tag','viewdomain'),'value',1)
      scgui(fig,'view')
      h = plotpoly(w,beta);
      set(h,'tag','polygon')
      scgui(fig,'domain')
    end
  end    
  
elseif strcmp(cmd,'solve')		%*** Solve button
  mapnum = get(findobj(fig,'tag','domain'),'value');
  types = str2mat('d','hp','st','r','de');
  map = deblank(types(mapnum,:));
  [w,beta] = scgget(fig,'ver','ang');
  if ~isempty(w) 
    z = scgget(fig,'pre');		% current soln for continuation
    trace = get(findobj(fig,'tag','trace'),'value');
    tol = 10^(-str2num(get(findobj(fig,'tag','tol'),'string')));
    ax(1) = findobj(fig,'tag','phydomain');
    ax(2) = findobj(fig,'tag','candomain');
    scgset(fig,'con',0)			% no current soln now

    % Force the physical domain temporarily
    domainmenu = findobj(fig,'tag','viewdomain');
    domain = get(domainmenu,'value');
    set(domainmenu,'value',1)
    scgui(fig,'view')
    
    set(ax,'buttondown','')
    axes(ax(2))
    cla 
    axis auto
    axis normal
    drawnow
    axes(ax(1))

    if strcmp(map,'r')			% rectangle map
      if ~isempty(z)			% continuation?
	c = scgget(fig,'con');
	[w,beta,z,corner] = rcorners(w,beta,z);
	z = r2strip(z,z,c(2));
      else
	disp('Use mouse to select images of rectangle corners.')
	disp('Go in counterclockwise order and select a long edge first.')
	title('Select rectangle corners')
	corner = scselect(w,beta,4);
	title('')
	drawnow
	[w,beta,corner] = scfix('r',w,beta,corner);
      end
      fprintf('Solving parameter problem...\n')
      title('Solving...'), drawnow
      [z,c,L] = rparam(w,beta,corner,z,[trace,tol]);
      c = [c;L];
    elseif strcmp(map,'st')		% strip map
      if ~isempty(z)			% continuation?
	ends = [find(isinf(z)&(z<0)),find(isinf(z)&(z>0))];
      else
	disp('Use mouse to select images of the ends of the strip.')
	title('Select ends of strip')
	ends = scselect(w,beta,2);
	title('')
	[w,beta,ends] = scfix('st',w,beta,ends);
      end
      fprintf('Solving parameter problem...\n')
      title('Solving...'), drawnow
      [z,c] = stparam(w,beta,ends,z,[trace,tol]);
    else				% other maps (d, hp, de)
      if isempty(z)
	[w,beta] = scfix(map,w,beta);
      end
      fprintf('Solving parameter problem...\n')
      title('Solving...'), drawnow
      eval(sprintf('[z,c] = %sparam(w,beta,z,[trace,tol]);',map))
    end
    fprintf('...finished.\n')
    
    title(''), drawnow
    cla 
    axis auto
    h = plotpoly(w,beta);
    set(h,'tag','polygon')
    % Create physical points object
    line('linesty','o','color',[0 1 1],'tag','phypoints',...
	'xdata',[],'ydata',[])
    
    scgset(fig,'ver',w,'ang',beta,'pre',z,'con',c,'map',mapnum)    
    set(domainmenu,'value',domain)
    scgui(fig,'plotcanonical')
    scgui(fig,'view')
  end

elseif strcmp(cmd,'plotcanonical')	%*** plot canonical domain
  [z,map] = scgget(fig,'pre','map');
  if ~isempty(z)			% must be a soln!
    axes(findobj(fig,'tag','candomain'))
    delete(findobj(gca,'tag','polygon'))
    if strcmp(map,'disk') | strcmp(map,'exterior')
      h = plot(exp(i*linspace(0,2*pi,100)),'linewid',1);
      axis([-1.1 1.1 -1.1 1.1])
      axis equal
      axis square
    elseif strcmp(map,'half-plane')
      xmin = min(z(~isinf(z)));
      xmax = max(z(~isinf(z)));
      xlim = [1.1*xmin-.1*xmax,1.1*xmax-.1*xmin];
      h = plot(xlim,[0,0],'linewid',1);
      axis normal
      axis([xlim,-.1,1])
    elseif strcmp(map,'strip')
      minx = min(real(z(~isinf(z))));
      maxx = max(real(z(~isinf(z))));
      d = (maxx-minx)/2;
      m = (maxx+minx)/2;
      h(1) = plot([m-1.1*d,m+1.1*d],[0,0],'linewid',1);
      h(2) = plot([m-1.1*d,m+1.1*d],[1,1],'linewid',1);
      axis normal
      axis([m-1.1*d,m+1.1*d,-.1,1.1])
    elseif strcmp(map,'rectangle')
      h = plotpoly(z);
    end 	
    set(h,'tag','polygon')
    % Create canonical points object
    line('linesty','o','color',[0 1 1],'tag','canpoints',...
	'xdata',[],'ydata',[])
    h = plot(z+eps*i,'.','mark',16,'color','r');
    set(h,'tag','polygon')
  end

elseif strcmp(cmd,'center')		%*** Center button
  [w,beta,z,c,map] = scgget(fig);
  if ~isempty(c) & strcmp(map,'disk')
    ax(1) = findobj(fig,'tag','phydomain');
    ax(2) = findobj(fig,'tag','candomain');
    % Show physical domain & turn off point mapping
    set(findobj(ax(1)),'vis','on')
    set(findobj(ax(2)),'vis','off')
    set(ax(1),'buttondown','')
    set(ax(2),'buttondown','')

    axes(ax(1))
    title('Click at conformal center')
    [xc,yc] = ginput(1);
    title('')
    [z,c] = dfixwc(w,beta,z,c,xc+i*yc);

    scgset(fig,'pre',z,'con',c)
    delete(findobj(fig,'tag','meshlines'))
    set(findobj(fig,'tag','phypoints'),'xdata',[],'ydata',[])
    set(findobj(fig,'tag','canpoints'),'xdata',[],'ydata',[])
    scgui(fig,'view')
  end

elseif strcmp(cmd,'display')		%*** Display button
  [w,beta,z,c,map] = scgget(fig);
  if ~isempty(c)
    if map(1)=='h', prefix = 'hp';
    elseif map(1)=='s', prefix = 'st';
    elseif map(1)=='e', prefix = 'de';
    else prefix = map(1);
    end
    if strcmp(prefix,'r')
      rdisp(w,beta,z,c(1),c(2))
    else
      eval(sprintf('%sdisp(w,beta,z,c)',prefix))
    end
  end

elseif strcmp(cmd,'plot')		%*** Plot button
  [w,beta,z,c,map] = scgget(fig);
  if ~isempty(c)
    ax(1) = findobj(fig,'tag','phydomain');
    ax(2) = findobj(fig,'tag','candomain');
    if map(1)=='h', prefix = 'hp';
    elseif map(1)=='s', prefix = 'st';
    elseif map(1)=='e', prefix = 'de';
    else prefix = map(1);
    end

    % Parse requested mesh lines
    xrhan = findobj(fig,'tag','XR');
    ythan = findobj(fig,'tag','YT');
    xrstring = get(xrhan,'string');
    ytstring = get(ythan,'string');
    if strcmp(xrstring,'defaults') | strcmp(xrstring,'default')
      xr = 10;
    else
      xr = str2num(xrstring);
    end
    if strcmp(ytstring,'defaults') | strcmp(ytstring,'default')
      yt = 10;
    else
      yt = str2num(ytstring);
    end

    set(findobj(ax(1)),'vis','on')
    set(findobj(ax(2)),'vis','off')
    axes(ax(1))
    delete(findobj(ax(1),'tag','meshlines'))
    delete(findobj(ax(1),'tag','polygon'))
    if strcmp(prefix,'de')
      set(ax(1),'xlimmode','auto','ylimmode','auto')
    end
    if strcmp(prefix,'r')
      [h,xr,yt] = rplot(w,beta,z,c(1),c(2),xr,yt);
    else
      eval(sprintf('[h,xr,yt] = %splot(w,beta,z,c,xr,yt);',prefix))
    end

    % Major kludge. Plotting routines plot their own copy of the polygon,
    % without returning handles. This locates and tags these lines.
    colr = get(ax(1),'colororder');
    hp = findobj(ax(1),'color',colr(1,:));
    set(hp,'tag','polygon')
    
    % Update mesh line information
    if isempty(xr)
      xrstring = '';
    else
      xrstring = ['[',sprintf('%.3g ',xr),']'];
    end
    if isempty(yt)
      ytstring = '';
    elseif strcmp(prefix,'d') | strcmp(prefix,'de')
      ytstring = ['pi*[',sprintf('%.3g ',yt/pi),']'];
    else
      ytstring = ['[',sprintf('%.3g ',yt),']'];
    end
    set(xrhan,'string',xrstring)
    set(ythan,'string',ytstring)

    set(h,'erasemode','none','tag','meshlines')
    
    % Draw them in canonical domain
    axes(ax(2))
    delete(findobj(ax(2),'tag','meshlines'))
    xr = xr(:)';
    yt = yt(:)';
    if strcmp(prefix,'d') | strcmp(prefix,'de')
      t = linspace(0,2*pi,101)';
      h1 = plot(exp(i*t)*xr,'g');
      h2 = plot([0;1]*exp(i*yt),'g');
    elseif strcmp(prefix,'hp')
      zf = z(~isinf(z));
      x = [real(zf);xr'];
      xlim = [min(x);max(x)];
      xlim = [1.1 -.1; -.1 1.1] * xlim;
      y = [imag(zf);yt'];
      ylim = [min(y);max(y)];
      ylim = [0 0; -.1 1.1]*ylim;
      plot(xlim,[0,0],'linewid',1)
      h1 = plot([1;1]*xr, ylim*ones(size(xr)), 'g');
      h2 = plot(xlim*ones(size(yt)), [1;1]*yt, 'g');
      axis([xlim',-0.05*ylim(2),ylim(2)])
    elseif strcmp(prefix,'st')
      zf = z(~isinf(z));
      x = [real(zf);xr'];
      xlim = [min(x);max(x)];
      xlim = [1.1 -.1; -.1 1.1] * xlim;
      ylim = [0;1];
      plot(xlim,[0,0],'linewid',1)
      plot(xlim,[1,1],'linewid',1)
      h1 = plot([1;1]*xr, ylim*ones(size(xr)), 'g');
      h2 = plot(xlim*ones(size(yt)), [1;1]*yt, 'g');
      axis([xlim',-.5,1.5])
    else
      xlim = [min(real(z));max(real(z))];
      ylim = [min(imag(z));max(imag(z))];
      h1 = plot([1;1]*xr, ylim*ones(size(xr)), 'g');
      h2 = plot(xlim*ones(size(yt)), [1;1]*yt, 'g');
    end
    set([h1;h2],'erasemode','none','tag','meshlines')
  end
  scgui(fig,'view')
  
elseif strcmp(cmd,'mappts')		%*** map selected points
  domain = get(findobj(fig,'tag','viewdomain'),'value');
  [w,beta,z,c,map] = scgget(fig);
  source = data;			% (given)
  images = [];
  if ~isempty(w) & ~isempty(c)
    title('Mapping...')
    drawnow
    map = get(findobj(fig,'tag','domain'),'value');
    prefix = str2mat('d','hp','st','r','de');
    source = source(~isnan(source));

    % Build command string
    if map==4
      evalstr = 'map(source,w,beta,z,c(1),c(2))';
    else
      evalstr = 'map(source,w,beta,z,c)';
    end
    if domain==1
      evalstr = ['inv',evalstr];
    end

    if ~isempty(source)
      eval(sprintf('images = %s%s;',deblank(prefix(map,:)),evalstr))
    else
      images = [];
    end
    title('')
    drawnow
  end
  out = images;
  
elseif strcmp(cmd,'addpt')		%*** add selected point (click)
  pt = get(gca,'currentpoint');
  % Map it
  img = scgui(fig,'mappts',pt(1,1)+i*pt(1,2));
  domain = get(findobj(fig,'tag','viewdomain'),'value');
  ax(1) = findobj(fig,'tag','phydomain');
  ax(2) = findobj(fig,'tag','candomain');
  
  h1 = findobj(fig,'tag','phypoints');
  h2 = findobj(fig,'tag','canpoints');
  if isempty(h1) | isempty(h2)
    % Don't exist, must create
    axes(ax(1))
    delete(h1)
    h1 = line('linesty','o','color',[0 1 1],'tag','phypoints',...
	'xdata',[],'ydata',[]);
    axes(ax(2))
    delete(h2)
    h2 = line('linesty','o','color',[0 1 1],'tag','canpoints',...
	'xdata',[],'ydata',[]);
  end
  h = [h1 h2];

  % Update objects to show points
  axes(ax(domain))
  set(h,'erasemode','none')
  x = get(h(domain),'xdata');
  y = get(h(domain),'ydata');
  set(h(domain),'xdata',[x(:);pt(1,1)],'ydata',[y(:);pt(1,2)],'vis','on')
  domain = 3-domain;
  x = get(h(domain),'xdata');
  y = get(h(domain),'ydata');
  set(h(domain),'xdata',[x(:);real(img)],'ydata',[y(:);imag(img)],'vis','off')
  set(h,'erasemode','normal')

elseif strcmp(cmd,'editpts')		%*** Edit points button
  domain = get(findobj(fig,'tag','viewdomain'),'value');
  h1 = findobj(fig,'tag','phypoints');
  h2 = findobj(fig,'tag','canpoints');
  
  % Solution and points objects must exist
  if ~isempty(scgget(fig,'con')) & ~isempty(h1) & ~isempty(h2)
    wp = get(h1,'xdata')+i*get(h1,'ydata');
    zp = get(h2,'xdata')+i*get(h2,'ydata');
    wp = wp(~isnan(wp));
    zp = zp(~isnan(zp));
    
    % Interpretation of box depends on current view domain
    if domain==1
      [flag,wp] = scgedit('Edit points','Physical',wp);
      if flag > 0
	zp = scgui(fig,'mappts',wp);
      end
    else
      [flag,zp] = scgedit('Edit points','Canonical',zp);
      if flag > 0
	wp = scgui(fig,'mappts',zp);
      end
    end
    if flag > 0
      % Update point objects
      set(h1,'xdata',real(wp(:))','ydata',imag(wp(:))')
      set(h2,'xdata',real(zp(:))','ydata',imag(zp(:))')
    end
  end
  
elseif strcmp(cmd,'importexport')	%*** Import/Export button
  % Find import/export window, or create if necessary
  fig2 = findobj(0,'tag','sc_importexport');
  if isempty(fig2)
    fig2 = figure('vis','off','number','off','name','Import/Export',...
	'tag','sc_importexport');
    labels = str2mat('Vertices','Angles','Prevertices','Constant',...
	'L (rectangle)','Physical pts','Canonical pts');
    names = str2mat('w','beta','','','','','');
    tags = str2mat('ver','ang','pre','con','ell','phy','can');
    pos = get(fig2,'pos');
    set(fig2,'pos',[pos(1),pos(2),230,310])
    uicontrol(fig2,'style','frame','pos',[0,280,230,30]);
    uicontrol(fig2,'style','frame','pos',[0,0,230,280]);
    uicontrol(fig2,'style','text','pos',[0,282,90,24],...
	'string','Quantity:');
    uicontrol(fig2,'style','text','pos',[100,282,120,24],...
	'string','Workspace name:');
    heights = 240:-30:60;
    for j=1:7
      uicontrol(fig2,'style','text','pos',[10,heights(j),90,24],...
	  'string',labels(j,:),'hor','l');
      uicontrol(fig2,'style','edit','pos',[135,heights(j),50,24],...
	  'string',deblank(names(j,:)),'tag',deblank(tags(j,:)));
    end
    % These buttons cause the actions to be taken
    uicontrol(fig2,'style','push','pos',[10,20,60,24],...
	'string','Import',...
	'call','global SC_FLAG SC_FIG, scgimprt, SC_FLAG=1;')
    uicontrol(fig2,'style','push','pos',[85,20,60,24],...
	'string','Export',...
	'call','global SC_FLAG SC_FIG, scgexprt, SC_FLAG=2;')
    uicontrol(fig2,'style','push','pos',[160,20,60,24],...
	'string','Cancel','call','global SC_FLAG, SC_FLAG=-1;')
  end					% (create window)
  
  % Reveal window and wait for action
  global SC_FLAG SC_FIG
  SC_FLAG = 0;
  SC_FIG = fig;
  set(fig2,'vis','on')
  while ~SC_FLAG
    drawnow
  end

  set(fig2,'vis','off')			% turn it off

  if SC_FLAG==1
    % Data was imported. Update the information
    [w,beta] = scgget(fig,'ver','ang');
    delete(findobj(fig,'tag','meshlines'))
    delete(findobj(fig,'tag','phypoints'))
    delete(findobj(fig,'tag','canpoints'))

    axes(findobj(fig,'tag','phydomain'))
    delete(findobj(gca,'type','line'))
    axis auto
    plotpoly(w,beta)
    
    % Set map type based on prevertices if given
    z = scgget(fig,'pre');
    if ~isempty(z)
      if all(abs(abs(z)-1) < 1e-10)
	if sum(beta) < 0
	  map = 1;			% disk
	else
	  map = 5;			% exterior
	end
      elseif sum(isinf(z))==1
	map = 2;			% half-plane
      elseif sum(isinf(z))==2
	map = 3;			% strip
      else
	map = 4;			% rectangle
      end
    else
      % Solution not given, so use current domain
      map = get(findobj(fig,'tag','domain'),'value');
    end
    set(findobj(fig,'tag','domain'),'value',map);
    scgset(fig,'map',map)
    scgui(fig,'plotcanonical')
    scgui(fig,'domain');
    scgui(fig,'view')
  end
  clear global SC_FLAG SC_FIG
  
elseif strcmp(cmd,'view')		%*** set phys/can view
  ax(1) = findobj(fig,'tag','phydomain');
  ax(2) = findobj(fig,'tag','candomain');
  viewdom = get(findobj(fig,'tag','viewdomain'),'value');
  % Set visibility, map-on-click functions
  if viewdom==1
    % Physical
    if scgget(fig,'con')
      set(findobj(ax(1)),'vis','on','buttondown','scgui(gcf,''addpt'')')
    else
      set(findobj(ax(1)),'vis','on','buttondown','')
    end
    set(findobj(ax(2)),'vis','off','buttondown','')
    axes(ax(1))
  else
    % Canonical
    set(findobj(ax(1)),'vis','off','buttondown','')
    if scgget(fig,'con')
      set(findobj(ax(2)),'vis','on','buttondown','scgui(gcf,''addpt'')')
    else
      set(findobj(ax(2)),'vis','on','buttondown','')
    end
    axes(ax(2))
  end
     
elseif strcmp(cmd,'domain')		%*** canonical domain selection
  map = get(findobj(fig,'tag','domain'),'value');
  types = str2mat('disk','half-plane','strip','rectangle','exterior');
  if ~strcmp(deblank(types(map,:)),scgget(fig,'map'))
    % can. domain has changed, so solution is not valid
    scgset(fig,'pre',[],'con',[])
    scgset(fig,'map',deblank(types(map,:)))
    delete(findobj(fig,'tag','phypoints'))
    axes(findobj(fig,'tag','candomain'))
    cla
  end
  
  % Mesh line options should be r/theta or x/y
  set(findobj(fig,'tag','XR'),'string','defaults');
  set(findobj(fig,'tag','YT'),'string','defaults');
  xrtext = findobj(fig,'tag','XRtext');
  yttext = findobj(fig,'tag','YTtext');
  if map==1 | map==5
    set(xrtext,'string','r =')
    set(yttext,'string','theta =')
  else
    set(xrtext,'string','x =')
    set(yttext,'string','y =')
  end
  
  % Clear all current mesh lines 
  delete(findobj(fig,'tag','meshlines'))

end
