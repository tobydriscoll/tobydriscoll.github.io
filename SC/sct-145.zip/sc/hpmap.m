function wp = hpmap(zp,w,beta,z,c,qdat)
%HPMAP  Schwarz-Christoffel half-plane map.
%	HPMAP(ZP,W,BETA,Z,C,QDAT) computes the values of the
%	Schwarz-Christoffel half-plane map at the points in vector ZP.  The
%	polygon's vertices should be given in W and the arguments Z, C, and
%	QDAT should be computed by HPPARAM.  HPMAP returns a vector the same
%	size as ZP. 
%	
%       HPMAP(ZP,W,BETA,Z,C,TOL) uses quadrature data intended to give an
%       answer accurate to within TOL.
%	
%	HPMAP(ZP,W,BETA,Z,C) uses a tolerance of 1e-8.
%
%	See also HPPARAM, HPPLOT, HPINVMAP.
%
%	Copyright 1996 by Toby Driscoll. Last updated 11/20/96.

n = length(w);
w = w(:);
beta = beta(:);
z = z(:);
if any(isinf(z))
  z(n) = [];
  beta(n) = [];
end

if nargin < 6
  qdat = scqdata(beta,8);
elseif length(qdat)==1
  qdat = scqdata(beta,max(ceil(-log10(qdat)),8));
end
wp = zeros(size(zp));
zp = zp(:);
p = length(zp);

% For each point in zp, find nearest prevertex.
[tmp,sing] = min(abs(zp(:,ones(length(z),1)).'-z(:,ones(1,p))));
sing = sing(:);				% indices of prevertices
atinf = find(isinf(w(1:length(z)))); 	% infinite vertices
atinf = atinf(:);
ninf = length(atinf);			% # of inf vertices
if ninf > 0
  % "Bad" points are closest to a prevertex of infinity.
  bad = sing(:,ones(ninf,1))' == atinf(:,ones(1,p));
  % Can be closest to any pre-infinity.
  if ninf > 1
    bad = any(bad);
  end
  % Exclude cases which are exactly those prevertices.
  bad = bad(:) & (abs(zp-z(sing)) > 10*eps);
  % Can't integrate starting at pre-infinity: which neighboring prevertex
  % to use?
  direcn = real(zp(bad)-z(sing(bad)));
  sing(bad) = sing(bad) + sign(direcn) + (direcn==0);
  % Midpoints of these integrations 
  mid = (z(sing(bad)) + zp(bad)) / 2;
else
  bad = zeros(p,1);
end
  
% zs = the starting singularities
% A MATLAB technicality could cause a mistake if sing is all ones and same
% length as z, hence a workaround.
zs = wp(:); zs(1:p+1) = z([sing;2]); zs = zs(1:p);
% ws = f(zs)
ws = wp(:); ws(1:p+1) = w([sing;2]); ws = ws(1:p);

% Compute the map directly at "normal" points.
if any(~bad)
  wp(~bad) = ws(~bad) + c*hpquad(zs(~bad),zp(~bad),sing(~bad),...
      z,beta,qdat);
end
% Compute map at "bad" points, stopping at midpoint to avoid integration
% where right endpoint is close to a singularity.
if any(bad)
  wp(bad) = ws(bad) + c*...
      (hpquad(zs(bad),mid,sing(bad),z,beta,qdat) -...
      hpquad(zp(bad),mid,zeros(sum(bad),1),z,beta,qdat));
end
  


