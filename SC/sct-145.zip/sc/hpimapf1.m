function zdot = imapf1(wp,yp);
%HPIMAPF1 (not intended for calling directly by the user)
%	Used by HPINVMAP for solution of an ODE.
%
%	Copyright 1996 by Toby Driscoll. Last updated 11/20/96.

global SCIMDATA 

lenyp = length(yp);
lenzp = lenyp/2;
zp = yp(1:lenzp)+sqrt(-1)*yp(lenzp+1:lenyp);
lenz = SCIMDATA(1,4);
bigz = SCIMDATA(1:lenz,2)*ones(1,lenyp/2);
bigbeta = SCIMDATA(1:lenz,3)*ones(1,lenyp/2);

f = SCIMDATA(1:lenzp,1).*exp(sum(log(ones(lenz,1)*zp.' - bigz).*...
    (-bigbeta))).';
zdot = [real(f);imag(f)];
