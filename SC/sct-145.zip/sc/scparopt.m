function [trace,tol,method] = scparopt(options)
%SCPAROPT Parameters used by S-C parameter problem routines.
%       OPTIONS(1): Nonzero causes some intermediate results to be
%                   displayed (default 0)
%       OPTIONS(2): Error tolerance for solution (default 1e-8)
%       OPTIONS(3): Solution strategy
%                      1 = line search
%                      2 = trust region (default)
%	
%	See also HPPARAM, DPARAM, DEPARAM, STPARAM, RPARAM.
%
%	Copyright 1996 by Toby Driscoll. Last updated 11/20/96.

user = options;
lenu = length(user);
options = zeros(1,3);
options(1:lenu) = user(1:lenu);
options = options + (options==0).*[0,1e-8,2];

trace = options(1);
tol = options(2);
method = options(3);

