SC_TAGS = str2mat('ver','ang','pre','con','ell','phy','can');
for SC_CTR = 1:7
  SC_TMP = get(findobj(gcf,'tag',SC_TAGS(SC_CTR,:)),'string');
  if ~isempty(SC_TMP)
    eval(sprintf('scgset(SC_FIG,''%s'',%s)',SC_TAGS(SC_CTR,:),SC_TMP),'[]');
  end
end

clear SC_TMP SC_CTR SC_TAGS
