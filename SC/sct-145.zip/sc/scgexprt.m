SC_TAGS = str2mat('ver','ang','pre','con','ell','phy','can');
for SC_CTR = [1:4,6:7]
  SC_TMP = get(findobj(gcf,'tag',SC_TAGS(SC_CTR,:)),'string');
  if ~isempty(SC_TMP)
    eval(sprintf('%s=scgget(SC_FIG,''%s'');',SC_TMP,SC_TAGS(SC_CTR,:)),'[]');
    if SC_CTR==4
      SC_TMPL = get(findobj(gcf,'tag',SC_TAGS(5,:)),'string');
      if ~isempty(SC_TMPL)
	eval(sprintf('%s=%s(2);',SC_TMPL,SC_TMP))
      end
      eval(sprintf('%s=%s(1);',SC_TMP,SC_TMP))
    end
  end
end

clear SC_TMP SC_CTR SC_TAGS SC_TMPL
