function [flag,x1,x2] = scgedit(name,xlab1,x1,xlab2,x2)
%SCGEDIT (not intended for calling directly by the user)
%	Pops up a figure window to edit some data.
%	
%	Copyright 1996 by Toby Driscoll. Last updated 11/20/96.

nvar = 1;
if nargin==5
  nvar = 2;
end

fig2 = figure('vis','off','number','off','name',name);
pos = get(fig2,'pos');
height = 150-34*(nvar==1);
set(fig2,'pos',[pos(1),pos(2),400,height])
uicontrol(fig2,'style','frame','pos',[0,0,400,height]);
for j=1:nvar
  height = 64+34*(nvar-j);
  eval(sprintf('xlab=xlab%d;x=x%d(:);',j,j))
  uicontrol(fig2,'style','text','pos',[10,height,80,24],...
      'string',xlab,'hor','r');
  xstr = ['[ ',sprintf(' %.4g%+.4gi ',[real(x)';imag(x)']),']'];
  ui(j) = uicontrol(fig2,'style','edit','pos',[100,height,290,24],...
      'string',xstr,'tag','scgeditbox');
end
uicontrol(fig2,'style','push','pos',[40,20,60,24],...
    'string','Clear','call',...
    'set(findobj(gcf,''tag'',''scgeditbox''),''string'',''[ ]'')')
uicontrol(fig2,'style','push','pos',[170,20,60,24],...
    'string','Done','call','global SC_FLAG,SC_FLAG=1;')
uicontrol(fig2,'style','push','pos',[300,20,60,24],...
    'string','Cancel','call','global SC_FLAG,SC_FLAG=-1;')
set(fig2,'vis','on')
global SC_FLAG
SC_FLAG = 0;
while ~SC_FLAG
  drawnow
end
flag = SC_FLAG;
clear global SC_FLAG

if flag > 0
  for j=1:nvar
    x = eval(get(ui(j),'string'),'[]');
    eval(sprintf('x%d=x;',j))
  end
end

delete(fig2)


