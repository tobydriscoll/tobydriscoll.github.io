function r = bezier(t,node,ctrl)
% BEZIER Cubic Bezier curve.
% Input:
%   t      parameter evaluation values (between 0 and 1)
%   node   coordinates of endpoints (two colums)
%   ctrl   coordinates of control points (two colums)
% Output:
%   r      points on curve (one column per t value)

t = t(:).';                       % make it a row vector

% Bernstein polyomials.
B0 = (1-t).^3;
B1 = 3*t.*(1-t).^2;
B2 = 3*t.^2.*(1-t);
B3 = t.^3;

r = node(:,1)*B0 + ctrl(:,1)*B1 + ctrl(:,2)*B2 + node(:,2)*B3;
