function P = plinterp(xi,x,y)
% PLINTERP Piecewise linear interpolation.
% Input:
%   xi  evaluation points for the interpolant (vector)
%   x   interpolation nodes (vector, length n+1)
%   y   interpolation values (vector, length n+1)
% Output:
%   P   values of the piecewise linear interpolant (vector)

n = length(x)-1;
P = zeros(size(xi));
for k = 1:n+1
  P = P + y(k)*hatfun(xi,x,k);
end