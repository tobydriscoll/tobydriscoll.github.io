function S = spinterp(xi,x,y)
% SPINTERP Cubic spline interpolation with not-a-knot end conditions.
% (B-spline implementation)
% Input:
%   xi  evaluation points for the interpolant (vector)
%   x   interpolation nodes (vector, length n+1)
%   y   interpolation values (vector, length n+1)
% Output:
%   S   values of the cubic spline interpolant (vector)

x = x(:);  y = y(:);  % ensure column vectors
n = length(x)-1;   h = max(diff(x));

% List of all the knots
knotlist = [ x(1)-[3 2 1]'*h; x([1 3:n-1 n+1]); x(n+1)+[1 2 3]'*h ];

% Assemble system matrix 
A = zeros(n+1);
for j = 1:n+1
  A(:,j) = Bspline(x,knotlist(j:j+4));
end

% Solve for coefficients
c = A\y;

% Compute interpolant
S = 0;
for j = 1:n+1
  S = S + c(j)*Bspline(xi,knotlist(j:j+4));
end

