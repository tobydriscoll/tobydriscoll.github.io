function P = polinterp(xi,x,y)
% POLINTERP Global polynomial interpolation using barycentric formulas.
% Input:
%   xi  evaluation points for the interpolant (vector)
%   x   interpolation nodes (vector, length n+1)
%   y   interpolation values (vector, length n+1)
% Output:
%   P   values of the interpolant (vector)

x = x(:);                    % column vector
n = length(x)-1; 

% Compute barycentric weights.

C = (x(end)-x(1)) / 4;       % scaling factor for stability
xc = x/C;

% Add one node at a time, computing inverse weights.
w = ones(n+1,1);
for m = 2:n+1
  d = (xc(1:m-1) - xc(m));   % a vector of node differences
  w(1:m-1) = w(1:m-1) .* d;  % update previous inv. weights
  w(m) = prod( -d );         % compute the new one
end
w = 1./w;                    % go from inverses to weights

% Compute interpolant.
numer = 0;  denom = 0;    
% Loop over the nodes.
for k = 1:length(x)
  d = xi - x(k);
  d(d==0) = eps;             % prevent infinity at nodes
  r = w(k) ./ d;             % basic barycentric term
  numer = numer + y(k)*r;
  denom = denom + r;
end
P = numer./denom;
