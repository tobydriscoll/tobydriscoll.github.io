function P = plinterp1(xi,x,y)
% PLINTERP Piecewise linear interpolation.
% Input:  
%    xi  evaluation points for the interpolant (vector)
%    x   interpolation nodes (vector, length n+1)
%    y   interpolation values (vector, length n+1)
% Output: 
%    P   values of the piecewise linear interpolant (vector)

n = length(x)-1;
P = NaN*zeros(size(xi));                % initialize output 
slope = diff(y) ./ diff(x);             % piecewise slopes
for k=1:n
  inside = find( xi>=x(k) & xi<=x(k+1) );  % find pts in this interval
  P(inside) = y(k) + slope(k)*(xi(inside)-x(k));  
end
