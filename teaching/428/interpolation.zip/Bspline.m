function B = Bspline(x,t)
% BSPLINE Evaluate a B-spline.
% Input:
%   x   evaluation points (vector)
%   t   knots (vector)
% Output:
%   B   values of B-spline

r = length(t)-1;

if r==1
  % Base case of recursion (piecewise constant).
  B = double( (x >= t(1)) & ( x < t(2)) );
else
  % Recursively appeal to next lower order.
  B1 = Bspline(x,t(1:r));
  B2 = Bspline(x,t(2:r+1));
  B = ((x-t(1))/(t(r)-t(1))).*B1 + ((t(r+1)-x)/(t(r+1)-t(2))).*B2;
end