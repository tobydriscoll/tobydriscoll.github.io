function S = spinterp1(xi,x,y)
% SPINTERP Cubic spline interpolation with not-a-knot end conditions.
% Input:
%   xi  evaluation points for the interpolant (vector)
%   x   interpolation nodes (vector, length n+1)
%   y   interpolation values (vector, length n+1)
% Output:
%   S   values of the cubic spline interpolant (vector)

x = x(:);  y = y(:);  % ensure column vectors
n = length(x)-1;
h = diff(x);  
H1 = diag(h);  H2 = diag(h.^2);  H3 = diag(h.^3);
D = toeplitz( [1;zeros(n-2,1)], [1 -1 zeros(1,n-2)] );

% Interpolation conditions (n rows)
A1 = [ H3 H2 H1 ];
rhs1 = diff(y);

% Continuity of S' and S'' (n-1 rows each)
A2 = [ 3*H2(1:n-1,:) 2*H1(1:n-1,:) D ];
rhs2 = zeros(n-1,1);
A3 = [ 3*H1(1:n-1,:) D zeros(n-1,n) ];
rhs3 = zeros(n-1,1);

% Not-a-knot end conditions (2 rows)
NAK = [ [1 -1 zeros(1,3*n-2)]; [zeros(1,n-2) 1 -1 zeros(1,2*n)] ];
rhs4 = [0;0];

% Assemble and solve system
coeff = [ A1;A2;A3;NAK ] \ [rhs1;rhs2;rhs3;rhs4];
coeff = reshape( coeff, [n,3] );
coeff(:,4) = y(1:n);  % known constant term in cubic

S = zeros(size(xi));
for k=1:n
  inside = (xi>=x(k)) & (xi<=x(k+1));
  S(inside) = polyval( coeff(k,:), xi(inside)-x(k) );
end