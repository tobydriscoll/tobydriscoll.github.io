function [x,y] = fdnonlin(ode,xspan,BC,n)
%FDNONLIN   Finite differences for the two-point boundary-value problem.
% Input:
%   ode     inputs x,y,y'; outputs [f,f_y,f_y'] to define the ODE (function)
%   xspan   endpoints of the independent var. interval (2-vector)
%   BC      boundary values for y (2-vector)
%   n       number of grid points (integer)
% Output:
%   x       space locations (vector, length n+1)
%   y       solution values (vector, length n+1)

h = diff(xspan)/n;
x = xspan(1) + h*(1:n-1)';  % nodes

% Differentiation matrices and the boundary "correction vectors".
row1 = [0 1 zeros(1,n-3)]/(2*h);
col1 = -row1;
D1 = toeplitz(col1,row1);
b1 = [ -BC(1); zeros(n-3,1); BC(2) ] / (2*h);
row1 = [-2 1 zeros(1,n-3)]/(h^2);
D2 = toeplitz(row1);
b2 = [ BC(1); zeros(n-3,1); BC(2) ] / (h^2);

% Initialize the iteration with a linear guess for the solution.
y = BC(1) + (1:n-1)'*diff(BC)/n;
yp = D1*y + b1;
[f,fy,fyp] = feval(ode,x,y,yp);
F = D2*y + b2 - f;    % F = y'' - f(x,y,y')

% Newton iteration for the interior solution values.
dy = Inf;  iter = 0;  % starting conditions
while (norm(F) > 1e-10) && (norm(dy) > 1e-10)
  J = D2 - diag(fy) - diag(fyp)*D1;
  dy = -J \ F;
  y = y + dy;
  yp = D1*y + b1;
  [f,fy,fyp] = feval(ode,x,y,yp);
  F = D2*y + b2 - f;
  iter = iter+1;
  if iter > 10
    warning('Newton iteration may not be converging.')
    break
  end
end
  
% Return vectors with boundary values.
x = [xspan(1); x; xspan(2)];
y = [BC(1); y; BC(2)];
