function [x,y] = femlin(linode,xspan,n)
%FEMLIN   Finite elements for the linear two-point boundary-value problem.
% Input:
%   linode   inputs x; outputs [c,d,f] to define the ODE (function)
%   xspan    endpoints of the independent var. interval (2-vector)
%   n        number of grid points (integer)
% Output:
%   x       space locations (vector, length n+1)
%   y       solution values (vector, length n+1)

h = diff(xspan)/n;
x = xspan(1) + h*(0:n)';  % nodes

% Elementwise matrix and vector contributions.
Ke = [1 -1; -1 1];
Me = (1/6)*[2 1; 1 2];
fe = (1/2)*[1;1];

% Find piecewise constant coefficient function values.
[c,d,f] = feval(linode,x); 
cbar = (c(1:n)+c(2:n+1)) / 2;
dbar = (d(1:n)+d(2:n+1)) / 2;
fbar = (f(1:n)+f(2:n+1)) / 2;

% Assemble global system, ignoring boundaries at first.
K = zeros(n+1,n+1);  M = zeros(n+1,n+1);  f = zeros(n+1,1);
for k = 1:n
  K(k:k+1,k:k+1) = K(k:k+1,k:k+1) + (cbar(k)/h) * Ke;
  M(k:k+1,k:k+1) = M(k:k+1,k:k+1) + (dbar(k)*h) * Me;
  f(k:k+1) = f(k:k+1) + (fbar(k)*h) * fe;
end  

% Trim border rows and columns due to zero BC.
K = K(2:n,2:n);  M = M(2:n:2:n);  f = f(2:n);

% Solve system for interior values.
y = (K+M) \ f;

% Return vector with boundary values.
y = [0; y; 0];
