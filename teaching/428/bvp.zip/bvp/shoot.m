function [x,y,s] = shoot(d2ydx2,xspan,BC,tol)
%SHOOT   Shooting method for the two-point boundary-value problem.
% Input:
%   d2ydx2   f(x,y,y') that defines the ODE (function)
%   xspan    endpoints of the independent var. interval (2-vector)
%   BC       boundary values for y (2-vector)
%   tol      desired tolerance for shooting slope (positive scalar)
% Output:
%   x       space locations (vector, length N+1)
%   y       solution/derivative values (array, length [N+1,2])
%   s       shooting initial slope (scalar)

ivpopt = odeset('reltol',tol/10,'abstol',tol/10);
optimopt = optimset('tolx',tol,'display','iter');

s = diff(BC) / diff(xspan);   % average slope for initial guess
s = fzero(@finalerr,s,optimopt);

  function Y = finalerr(s)
  [x,y] = ode45(@shootivp,xspan,[BC(1) s],ivpopt);
  Y = y(end,1) - BC(2);
  end
  
  function f = shootivp(x,u)
  f = [ u(2); d2ydx2(x,u(1),u(2)) ];
  end

end