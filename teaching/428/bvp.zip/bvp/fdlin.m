function [x,y] = fdlin(linode,xspan,BC,n)
%FDLIN   Finite differences for the linear two-point boundary-value problem.
% Input:
%   linode   inputs x; outputs [p,q,r] to define the ODE (function)
%   xspan    endpoints of the independent var. interval (2-vector)
%   BC       boundary values for y (2-vector)
%   n        number of grid points (integer)
% Output:
%   x       space locations (vector, length n+1)
%   y       solution values (vector, length n+1)

h = diff(xspan)/n;
x = xspan(1) + h*(1:n-1)';  % nodes

% Build the Toeplitz differentiation matrices.
row1 = [0 1 zeros(1,n-3)]/(2*h);
col1 = -row1;
D1 = toeplitz(col1,row1);
b1 = [ -BC(1); zeros(n-3,1); BC(2) ] / (2*h);
row1 = [-2 1 zeros(1,n-3)]/(h^2);
D2 = toeplitz(row1);
b2 = [ BC(1); zeros(n-3,1); BC(2) ] / (h^2);

[p,q,r] = feval(linode,x);   % coefficient functions for ODE
P = diag(p);  Q = diag(q);

% Assemble and solve system for interior values.
A = D2 - P*D1 - Q;
b = r - b2 + P*b1;

y = A\b;  

% Return vectors with boundary values.
x = [xspan(1); x; xspan(2)];
y = [BC(1); y; BC(2)];
