function [I,x] = adaptsimp(f,a,b,tol,fl,fm,fr)
%ADAPTSIMP Adaptive implementation of Simpson's rule with error control.
% Input:
%   f     integrand (function)
%   a     left endpoint (scalar)
%   b     right endpoint (scalar)
%   tol   desired error bound (scalar)
% Output:
%   I     estimate of int(f,a..b)
%   x     evaluation nodes of f (vector, for information only)

m = (a+b)/2;  h = (b-a)/2;

% Find the f-values if not supplied recursively.
if nargin==4   
  fl = feval(f,a);
  fm = feval(f,m);
  fr = feval(f,b);
end

% Simpson rule estimates at two stepsizes.
S1 = (h/3) * (fl + 4*fm + fr);
lm = (a+m)/2;  flm = feval(f,lm);
rm = (m+b)/2;  frm = feval(f,rm);
S2 = (h/6) * (fl + 4*flm + 2*fm + 4*frm + fr);

delta = (S1-S2)/15;   % error estimate for S2
if abs(delta) < tol   % accept
  I = S2;
  x = [a lm m rm b]';
else                  % divide and conquer
  [I1,x1] = adaptsimp(f,a,m,tol/2,fl,flm,fm);
  [I2,x2] = adaptsimp(f,m,b,tol/2,fm,frm,fr);
  I = I1+I2;
  x = [ x1; x2(2:end) ];   % midpoint is duplicated
end