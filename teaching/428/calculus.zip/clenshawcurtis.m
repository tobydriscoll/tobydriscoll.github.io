 function [x,w] = clenshawcurtis(n)
% CLENSHAWCURTIS Nodes and weights for Clenshaw-Curtis quadrature
% Input:
%    n   one less than the number of nodes (even scalar)
% Output:
%    x   nodes (n+1 column vector) 
%    w   weights (n+1 row vector)

theta = pi*(0:n)'/n;
x = -cos(theta);
w = zeros(1,n+1); 
w([1 n+1]) = 1/(n^2-1); 
theta = theta(2:n); 
v = ones(n-1,1);
for k = 1:n/2-1
  v = v - 2*cos(2*k*theta)/(4*k^2-1);
end
v = v - cos(n*theta)/(n^2-1);
w(2:n) = 2*v/n;
