function [x,t,u] = BExx(xspan,Nx,tspan,Nt,initfun)
% BEXX   Backward Euler method for the heat equation.
% Input:
%   xspan     endpoints of space interval (2-vector)
%   Nx        number of points in space (integer)
%   tspan     endpoints of time interval (2-vector)
%   Nt        number of time steps (integer)
%   initfun   initial condition u(x,0) (function)
% Output:
%   x         space points (vector, length Nx)
%   t         time values (vector, length Nt+1)
%   u         solution in space-time (array, Nx by Nt+1)

dt = diff(tspan)/Nt;
t = tspan(1) + dt*(0:Nt)';              % time vector

dx = diff(xspan)/Nx;
x = xspan(1) + dx*(0:Nx-1)';            % space vector
D = toeplitz( [-2 1 zeros(1,Nx-3) 1]/dx^2 );   % diff'n matrix

u = zeros(Nx,Nt+1);                     % storage for all space-time
u(:,1) = feval(initfun,x);              % initial value

B = sparse( eye(Nx) - dt*D );           % iteration matrix
[L,U] = lu(B);                          % one LU factorization

for j = 1:Nt
  u(:,j+1) = U \ (L\u(:,j));            % BE iteration
end
u = [u(:,:); u(1,:)];                   % add right endpoint
x = [x; xspan(2)]; 
