function [x,t,u] = ODE15x(xspan,Nx,tspan,initfun)
% ODE15X   ode15s for the semidiscretized heat equation.
% Input:
%   xspan     endpoints of space interval (2-vector)
%   Nx        number of points in space (integer)
%   tspan     endpoints of time interval (2-vector)
%   initfun   initial condition u(x,0) (function)
% Output:
%   x         space points (vector, length Nx)
%   t         time values (vector, length Nt+1)
%   u         solution in space-time (array, Nx by Nt+1)

dx = diff(xspan)/Nx;
x = xspan(1) + dx*(0:Nx-1)';            % space vector
D = sparse( toeplitz([-2 1 zeros(1,Nx-3) 1]/(dx^2)) );    % diff'n matrix

  function f = dudt(t,u)
    f = D*u;
  end   % end nested function

[t,u] = ode15s(@dudt,tspan,feval(initfun,x));

u = u';     % space varies down rows
end         % end main function
