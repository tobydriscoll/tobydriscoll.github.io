function [X,Y,W] = poissonfd(poisfun,xspan,yspan,N,M)
%POISSONFD   Finite differences for the Poisson equation.
%            General Dirichlet case
% Input:
%   poisfun      forcing function/right-hand side (function of x,y)
%                      includes boundary terms
%   xspan        end values in x (vector)
%   yspan        end values in y (vector)
%   n            number of grid points in x dimension (integer)
%   m            number of grid points in y dimension (integer)
% Output:
%   X,Y          grid matrices (arrays, n+1 by n+1)
%   W            solution (array, n+1 by n+1)


% Initialize step sizes, mesh points
h = diff(xspan)/N;
k = diff(yspan)/M;
x = xspan(1) + h*(0:N)';
y = yspan(1) + k*(0:M)';
[X,Y] = meshgrid(x,y);

% Set up a logical array that flags boundary points
on_bdy = zeros(size(X));
on_bdy(:,[1 end]) = 1;                  % first and last cols
on_bdy([1 end],:) = 1;                  % first and last rows
on_bdy = logical(on_bdy(:));            % boolean column vector

% Set up one-dimensional 2nd-derivative matrices (D^(x), D^(y))
Dx = toeplitz( [-2;1;zeros(N-1,1)]/h^2 );
Dy = toeplitz( [-2;1;zeros(M-1,1)]/k^2 );

% Form discrete Laplacian on entire grid
A = kron(Dx,eye(M+1)) + kron(eye(N+1),Dy);

% Form right-hand side on interior points only
f = feval(poisfun,X(~on_bdy),Y(~on_bdy),'interior');

% Initialize solution values
w = zeros(size(X(:)));
w(on_bdy) = feval(poisfun,X(on_bdy),Y(on_bdy),'boundary');

% Modify right-hand side to account for known values
f = f - A(~on_bdy,on_bdy)*w(on_bdy);

% Solve reduced system for interior nodes
w(~on_bdy) = A(~on_bdy,~on_bdy) \ f;

% Reshape u to matrix form
W = reshape(w,M+1,N+1);
