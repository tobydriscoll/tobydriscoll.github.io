function [x,t,w] = eulerxx(initcond,alpha,tfinal,N,M)

% Initialization
h = 1/N;
x = (0:N)'*h;
k = tfinal/M;
t = (0:M)'*k;
lambda = alpha^2*k/h^2;
w = zeros(N+1,M+1);
w(2:N,1) = feval(initcond,x(2:N));

% Form Toeplitz matrix to advance system
A = toeplitz([1-2*lambda lambda zeros(1,N-3)]);

% Time stepping
for j = 1:M
  w(2:N,j+1) = A*w(2:N,j);
end
