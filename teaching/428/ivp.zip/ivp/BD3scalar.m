function [t,w] = BD3(dydt,tspan,y0,N)
% BD3   Third-order backward differentiation method for a scalar IVP.
% Input:
%   dydt    f(t,y) for the ODE (function)
%   tspan   endpoints of time interval (2-vector)
%   y0      initial value (scalar)
%   N       number of time steps (integer)
% Output:
%   t       vector of times (vector, length N+1)
%   w       w(i) is the solution at time t(i) (vector, length N+1)

h = diff(tspan)/N;   % stepsize
t = tspan(1) + h*(0:N)';
w = zeros(N+1,1);    % preallocation

% Define the method.
m = 3;  a = [2 -9 18]/11;  hb = h*6/11;

% Starting values by RK4.
if m > 1
  [ts,ws] = RK4(dydt,[0 (m-1)*h],y0,m-1);
  w(1:m) = ws;
end

% Iteration.
opt = optimset('display','none','tolx',1e-12);
for i = m:N
  w(i+1) = fzero(@residual,w(i),opt,dydt,t(i+1),w(i-m+1:i),a,hb);
end


function r = residual(u,dydt,ti1,w,a,hb)

f = feval(dydt,ti1,u);
r = u - a*w - hb*f;
