function [t,w] = ab4(dydt,tspan,y0,N)
% Fourth-order Adams-Bashforth method

h = (tspan(2)-tspan(1))/N;
t = tspan(1) + (0:N)'*h;
m = 4;  b = [-9 37 -59 55]/24;  % method order and coefficients

% Starting values by RK4.
w = zeros(N+1,length(y0));
[ts,ws] = rk4(dydt,tspan(1)+[0 (m-1)*h],y0,m-1);
w(1:m,:) = ws(1:m,:);

% Starting time derivatives.
f = zeros(m,length(y0));
for i = 1:m
  f(i,:) = feval(dydt,t(i),w(i,:));
end

% Main iteration.
for i = m:N
  w(i+1,:) = w(i,:) + h*(b*f);
  f = [f(2:m,:); feval(dydt,t(i+1),w(i+1,:))];
end

