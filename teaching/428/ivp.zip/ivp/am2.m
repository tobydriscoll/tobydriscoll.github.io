function [t,w] = am2(dydt,tspan,y0,N)
% AM2    Second-order Adams-Moulton rule (trapezoid) for an IVP.
%        Scalar problems only!

h = (tspan(2)-tspan(1))/N;
t = tspan(1) + (0:N)'*h;
w = zeros(N+1,1);
w(1) = y0;

% Main iteration
for i = 1:N
  % Data that does not depend on the new value w(i+1).
  known = w(i) + h/2*dydt(t(i),w(i));
  % Do the rootfinding.
  w(i+1) = fzero(@trapzero,w(i),1e-14);
end

% Function that defines the rootfinding problem at each step.
function F = trapzero(u)
  F = u - h/2*dydt(t(i+1),u) - known;
end


end  % main function