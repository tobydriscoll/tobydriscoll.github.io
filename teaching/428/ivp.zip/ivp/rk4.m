function [t,w] = rk4(dydt,tspan,y0,N)
% RK4   Euler's method for an initial-value problem.
% Input:
%   dydt    f(t,y) for the ODE (function)
%   tspan   endpoints of time interval (2-vector)
%   y0      initial value (vector, length M)
%   N       number of time steps (integer)
% Output:
%   t       vector of times (vector, length N+1)
%   w       w(i,:) is the solution at time t(i) (array, size [N+1 M])
%                  row k contains solution components at t(k)

h = (tspan(2)-tspan(1))/N;
t = tspan(1) + (0:N)'*h;
w = zeros(N+1,length(y0));
w(1,:) = y0(:).';
for i = 1:N
  k1 = h*dydt( t(i),     w(i,:) );
  k2 = h*dydt( t(i)+h/2, w(i,:)+k1/2 );
  k3 = h*dydt( t(i)+h/2, w(i,:)+k2/2 );
  k4 = h*dydt( t(i)+h,   w(i,:)+k3 );
  w(i+1,:) = w(i,:) + (k1 + 2*k2 + 2*k3 + k4)/6;
end
