function [t,w] = eulersys(dydt,tspan,y0,N)
% EULER1   Euler's method for a system initial-value problem.
% Input:
%   dydt    Defines f in y'(t)=f(t,y). (callable function)
%   tspan   endpoints of time interval (2-vector)
%   y0      initial value (vector, length M)
%   N       number of time steps (integer)
% Output:
%   t       selected mesh points  (vector, length N+1)
%   w       solution values   (array, (N+1)-by-M)

a = tspan(1);  b = tspan(2);
h = (b-a)/N;
t = a + (0:N)'*h;
M = length(y0);
w = zeros(M,N+1);
w(:,1) = y0(:);
for i = 1:N
  w(:,i+1) = w(:,i) + h*dydt(t(i),w(:,i));
end
w = w.';
