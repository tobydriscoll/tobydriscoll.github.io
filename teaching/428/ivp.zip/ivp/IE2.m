function [t,w] = ie2(dydt,tspan,y0,N)
% IE2   The improved Euler method for an initial-value problem.
% Input:
%   dydt    f(t,y) for the ODE (function)
%   tspan   endpoints of time interval (2-vector)
%   y0      initial value (vector, length M)
%   N       number of time steps (integer)
% Output:
%   t       vector of times (vector, length N+1)
%   w       w(i,:) is the solution at time t(i) (array, size [N+1 M])

M = length(y0);      % dimension
h = diff(tspan)/N;   % stepsize
t = tspan(1) + h*(0:N)';
w = zeros(N+1,M);    % preallocation
w(1,:) = y0(:).';

for i = 1:N
  w1 = w(i,:) + (h/2)*dydt(t(i),w(i,:));
  w(i+1,:) = w(i,:) + h*dydt(t(i)+h/2,w1);
end