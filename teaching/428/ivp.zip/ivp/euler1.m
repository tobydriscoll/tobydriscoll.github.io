function [t,w] = euler1(dydt,tspan,y0,N)
% EULER1   Euler's method for a scalar initial-value problem.
% Input:
%   dydt    Defines f in y'(t)=f(t,y). (callable function)
%   tspan   endpoints of time interval (2-vector)
%   y0      initial value 
%   N       number of time steps (integer)
% Output:
%   t       selected mesh points  (vector, length N+1)
%   w       solution values   (vector, length N+1)

a = tspan(1);  b = tspan(2);
h = (b-a)/N;
t = a + (0:N)'*h;
w = zeros(N+1,1);
w(1) = y0;
for i = 1:N
  w(i+1) = w(i) + h*dydt(t(i),w(i));
end
