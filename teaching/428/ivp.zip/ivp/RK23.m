function [t,w] = RK23(dydt,tspan,y0,tol)
% RK23   Adaptive RK method based on an order 2-3 embedded pair.
% Input:
%   dydt    f(t,y) for the ODE (function)
%   tspan   endpoints of time interval (2-vector)
%   y0      initial value (vector, length M)
%   tol     global error target (positive scalar)
% Output:
%   t       vector of times (vector, length N+1)
%   w       w(i,:) is the solution at time t(i) (array, size [N+1 M])

t = tspan(1);
w = y0(:).';
i = 1;

h = 0.5*tol^(1/3);
s1 = feval(dydt, t(1), w(1,:));
while t(i) < tspan(2)
  % Detect underflow of step size.
  if t(i)+h == t(i)
    msg = sprintf('Stepsize too small--possible singularity near t=%.6g',t(i));
    warning(msg)
    break
  end
  % Two new internal RK stages.
  s2 = feval(dydt, t(i)+2*h/3, w(i,:)+2*h*s1/3 );
  s3 = feval(dydt, t(i)+2*h/3, w(i,:)+2*h*s2/3 );
  E = h*norm( 3*(s2-s3)/8, Inf);          % 2nd-3rd difference
  maxerr = tol*( 1 + norm(w(i,:),Inf) );  % adjust for growing solution
  if E < maxerr                           % accept step
    t(i+1) = t(i) + h;
    w(i+1,:) = w(i,:) + (h/4)*(s1+3*s2);  % 2nd order solution
    i = i+1;
    s1 = feval(dydt, t(i), w(i,:));
  end
  q = 0.8*(maxerr/E)^(1/3);       % conservative optimal step factor
  q = min(q,4);                   % limit stepsize growth
  h = min(q*h,tspan(2)-t(i));     % don't step past end
end