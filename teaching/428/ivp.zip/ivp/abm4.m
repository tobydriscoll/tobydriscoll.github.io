function [t,w] = abm4(dydt,tspan,y0,N)
% Fourth-order AB/AM predictor-corrector.

h = diff(tspan)/N;
t = tspan(1) + (0:N)'*h;

% Starting values
w = zeros(N+1,length(y0));
[ts,ws] = rk4(dydt,tspan(1)+[0 3*h],y0,3);
w(1:4,:) = ws;

% Starting time derivatives
f = zeros(4,length(y0));
for i = 1:4
  f(i,:) = dydt(t(i),w(i,:));
end

% Main iteration
bp = [-9 37 -59 55]/24;  % predictor coeffs
bc = [1 -5 19 9]/24;     % corrector coeffs
for i = 4:N
  wp = w(i,:) + h*(bp*f);
  f = [ f(2:4,:); dydt(t(i+1),wp) ];
  w(i+1,:) = w(i,:) + h*(bc*f);
  f(4,:) = dydt(t(i+1),w(i+1,:));
end

